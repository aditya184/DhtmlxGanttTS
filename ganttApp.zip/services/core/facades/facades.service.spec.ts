import { TestBed } from '@angular/core/testing';

import { FacadesService } from './facades.service';

describe('FacadesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FacadesService = TestBed.get(FacadesService);
    expect(service).toBeTruthy();
  });
});
