import { TestBed } from '@angular/core/testing';

import { EditorsService } from './editors.service';

describe('EditorsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EditorsService = TestBed.get(EditorsService);
    expect(service).toBeTruthy();
  });
});
