import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PublishHelpersService {

  constructor() { }

  voidScriptSecond() {

    // "use strict";

    // Object.defineProperty(exports, "__esModule", { value: true });
    // all builds except for evaluation version get this mockup
    // the evaluation build gets actual codes
    return { default : (function (gantt) { })};


    /***/
  }

  voidScriptThird() {

    // "use strict";

    // Object.defineProperty(exports, "__esModule", { value: true });
    // all builds except for evaluation version get this mockup
    // the evaluation build gets actual codes
    return { default : (function (gantt) { })};


    /***/
  }
}
