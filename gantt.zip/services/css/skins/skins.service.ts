import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SkinsService {

  constructor() { }

  // broadway() {

  broadway(gantt) {
    gantt.skins.broadway = {
      config: {
        grid_width: 360,
        row_height: 35,
        scale_height: 35,
        link_line_width: 1,
        link_arrow_size: 7,
        lightbox_additional_height: 86
      },
      _second_column_width: 90,
      _third_column_width: 80,

      _lightbox_template: "<div class='gantt_cal_ltitle'><span class='gantt_mark'>&nbsp;</span><span class='gantt_time'></span><span class='gantt_title'></span><div class='gantt_cancel_btn'></div></div><div class='gantt_cal_larea'></div>",
      _config_buttons_left: {},
      _config_buttons_right: {
        "gantt_delete_btn": "icon_delete",
        "gantt_save_btn": "icon_save"
      }
    };
  }

  /***/
  // }

  // contrastBlack() {

  contrastBlack(gantt) {
    gantt.skins["contrast_black"] = {
      config: {
        grid_width: 360,
        row_height: 35,
        scale_height: 35,
        link_line_width: 2,
        link_arrow_size: 6,
        lightbox_additional_height: 75
      },
      _second_column_width: 100,
      _third_column_width: 80
    };

  }

  /***/
  // }

  // contrastWhite() {

  contrastWhite(gantt) {
    gantt.skins["contrast_white"] = {
      config: {
        grid_width: 360,
        row_height: 35,
        scale_height: 35,
        link_line_width: 2,
        link_arrow_size: 6,
        lightbox_additional_height: 75
      },
      _second_column_width: 100,
      _third_column_width: 80
    };

  }

  /***/
  // }

  // material() {

  material(gantt) {
    gantt.skins.material = {
      config: {
        grid_width: 411,
        row_height: 34,
        task_height_offset: 6,
        scale_height: 36,
        link_line_width: 2,
        link_arrow_size: 6,
        lightbox_additional_height: 80
      },
      _second_column_width: 110,
      _third_column_width: 75,
      _redefine_lightbox_buttons: {
        "buttons_left": ["dhx_delete_btn"],
        "buttons_right": ["dhx_save_btn", "dhx_cancel_btn"]
      }
    };

    gantt.attachEvent("onAfterTaskDrag", function (id) {
      var t = gantt.getTaskNode(id);
      if (t) {
        t.className += " gantt_drag_animation";
        setTimeout(function () {
          var indx = t.className.indexOf(" gantt_drag_animation");
          if (indx > -1) {
            t.className = t.className.slice(0, indx);
          }
        }, 200);
      }
    });

  }

  /***/
  // }

  // meadow() {

  meadow(gantt) {
    gantt.skins.meadow = {
      config: {
        grid_width: 350,
        row_height: 27,
        scale_height: 30,
        link_line_width: 2,
        link_arrow_size: 6,
        lightbox_additional_height: 72
      },
      _second_column_width: 95,
      _third_column_width: 80
    };

  }

  /***/
  // }

  // skyblue() {

  skyblue(gantt) {
    gantt.skins.skyblue = {
      config: {
        grid_width: 350,
        row_height: 27,
        scale_height: 27,
        link_line_width: 1,
        link_arrow_size: 8,
        lightbox_additional_height: 75
      },
      _second_column_width: 95,
      _third_column_width: 80
    };

  }

  /***/
  // }

  // terrace() {

  terrace(gantt) {
    gantt.skins.terrace = {
      config: {
        grid_width: 360,
        row_height: 35,
        scale_height: 35,
        link_line_width: 2,
        link_arrow_size: 6,
        lightbox_additional_height: 75
      },
      _second_column_width: 90,
      _third_column_width: 70
    };

  }

  /***/
  // }

  terraceCss() {

    // extracted by mini-css-extract-plugin

    /***/
  }
}
