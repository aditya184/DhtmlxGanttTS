import { Injectable } from '@angular/core';
import { UtilsService } from 'src/app/services/utils/utils.service';

@Injectable({
  providedIn: 'root'
})
export class TasksGridHelpersService {

  constructor(private utilsService: UtilsService) { }

  dropTarget() {

    /**
     * The state object for order branch drag and drop
     */

    var utils = this.utilsService.utils();

    return {
      createDropTargetObject: function createDropTargetObject(parent?) {
        var res = {
          targetParent: null,
          targetIndex: 0,
          targetId: null,
          child: false,
          nextSibling: false,
          prevSibling: false
        };

        if (parent) {
          utils.mixin(res, parent, true);
        }
        return res;
      },
      nextSiblingTarget: function nextSiblingTarget(dndTaskId, targetTaskId, store) {
        var result = this.createDropTargetObject();
        result.targetId = targetTaskId;
        result.nextSibling = true;
        result.targetParent = store.getParent(result.targetId);
        result.targetIndex = store.getBranchIndex(result.targetId);
        if (store.getParent(dndTaskId) != result.targetParent || result.targetIndex < store.getBranchIndex(dndTaskId)) {
          result.targetIndex += 1;
        }
        return result;
      },
      prevSiblingTarget: function prevSiblingTarget(dndTaskId, targetTaskId, store) {
        var result = this.createDropTargetObject();
        result.targetId = targetTaskId;
        result.prevSibling = true;
        result.targetParent = store.getParent(result.targetId);
        result.targetIndex = store.getBranchIndex(result.targetId);
        if (store.getParent(dndTaskId) == result.targetParent && result.targetIndex > store.getBranchIndex(dndTaskId)) {
          result.targetIndex -= 1;
        }
        return result;
      },
      firstChildTarget: function firstChildTarget(dndTaskId, targetTaskId, store) {
        var result = this.createDropTargetObject();
        result.targetId = targetTaskId;
        result.targetParent = result.targetId;
        result.targetIndex = 0;
        result.child = true;
        return result;
      },
      lastChildTarget: function lastChildTarget(dndTaskId, targetTaskId, store) {
        var children = store.getChildren(targetTaskId);
        var result = this.createDropTargetObject();
        result.targetId = children[children.length - 1];
        result.targetParent = targetTaskId;
        result.targetIndex = children.length;
        result.nextSibling = true;
        return result;
      }
    };

    /***/
  }

  highlight() {

    var domHelpers = this.utilsService.domHelpers();

    /**
     * methods for highlighting current drag and drop position
     */

    function highlightPosition(target, root, grid) {
      var markerPos = getTaskMarkerPosition(target, grid);
      // setting position of row
      root.marker.style.left = markerPos.x + 9 + "px";
      root.marker.style.top = markerPos.y + "px";
      var markerLine = root.markerLine;
      if (!markerLine) {
        markerLine = document.createElement("div");
        markerLine.className = "gantt_drag_marker gantt_grid_dnd_marker";
        markerLine.innerHTML = "<div class='gantt_grid_dnd_marker_line'></div>";
        markerLine.style.pointerEvents = "none";
        document.body.appendChild(markerLine);
        root.markerLine = markerLine;
      }
      if (target.child) {
        highlightFolder(target, markerLine, grid);
      } else {
        highlightRow(target, markerLine, grid);
      }
    }

    function removeLineHighlight(root) {
      if (root.markerLine && root.markerLine.parentNode) {
        root.markerLine.parentNode.removeChild(root.markerLine);
      }
      root.markerLine = null;
    }

    function highlightRow(target, markerLine, grid) {
      var linePos = getLineMarkerPosition(target, grid);

      markerLine.innerHTML = "<div class='gantt_grid_dnd_marker_line'></div>";
      markerLine.style.left = linePos.x + "px";
      markerLine.style.height = "4px";

      markerLine.style.top = (linePos.y - 2) + "px";
      markerLine.style.width = linePos.width + "px";

      return markerLine;
    }
    function highlightFolder(target, markerFolder, grid) {
      var id = target.targetParent;
      var pos = gridToPageCoordinates({ x: 0, y: grid.getItemTop(id) }, grid);

      markerFolder.innerHTML = "<div class='gantt_grid_dnd_marker_folder'></div>";
      markerFolder.style.width = grid.$grid_data.offsetWidth + "px";
      markerFolder.style.top = pos.y + "px";
      markerFolder.style.left = pos.x + "px";
      markerFolder.style.height = grid.getItemHeight(id) + "px";
      return markerFolder;
    }

    function getLineMarkerPosition(target, grid) {
      var store = grid.$config.rowStore;
      var pos: any = { x: 0, y: 0 };
      var indentNode = grid.$grid_data.querySelector(".gantt_tree_indent");
      var indent = 15;
      var level = 0;
      if (indentNode) {
        indent = indentNode.offsetWidth;
      }
      var iconWidth = 40;
      if (target.targetId !== store.$getRootId()) {
        var itemTop = grid.getItemTop(target.targetId);
        var itemHeight = grid.getItemHeight(target.targetId);
        level = store.exists(target.targetId) ? store.calculateItemLevel(store.getItem(target.targetId)) : 0;

        if (target.prevSibling) {
          pos.y = itemTop;
        } else if (target.nextSibling) {
          var childCount = 0;
          store.eachItem(function (child) {
            if (store.getIndexById(child.id) !== -1)
              childCount++;
          }, target.targetId);

          pos.y = itemTop + itemHeight + childCount * itemHeight;
        } else {
          pos.y = itemTop + itemHeight;
          level += 1;
        }
      }
      pos.x = iconWidth + level * indent;
      pos.width = Math.max(grid.$grid_data.offsetWidth - pos.x, 0);
      return gridToPageCoordinates(pos, grid);
    }

    function gridToPageCoordinates(pos, grid) {
      var gridPos = domHelpers.getNodePosition(grid.$grid_data);
      pos.x += gridPos.x - grid.$grid.scrollLeft;
      pos.y += gridPos.y - grid.$grid_data.scrollTop;
      return pos;
    }

    function getTaskMarkerPosition(e, grid) {
      var pos = domHelpers.getNodePosition(grid.$grid_data);
      var ePos = domHelpers.getRelativeEventPosition(e, grid.$grid_data);
      var store = grid.$config.rowStore;
      // row offset
      var x = pos.x;
      var y = ePos.y - 10;

      var config = grid.$getConfig();
      // prevent moving row out of grid_data container
      if (y < pos.y) y = pos.y;
      var gridHeight = store.countVisible() * config.row_height;
      if (y > pos.y + gridHeight - config.row_height) y = pos.y + gridHeight - config.row_height;

      pos.x = x;
      pos.y = y;
      return pos;
    }

    return {
      removeLineHighlight: removeLineHighlight,
      highlightPosition: highlightPosition
    };


    /***/
  }

  lockedLevel() {

    /**
     * resolve dnd position of the task when gantt.config.order_branch_free = false
     */

    var dropTarget = this.dropTarget();

    function getLast(store) {
      var current = store.getNext();
      while (store.exists(current)) {

        var next = store.getNext(current);
        if (!store.exists(next)) {
          return current;
        } else {
          current = next;
        }
      }
      return null;
    }

    function findClosesTarget(dndTaskId, taskId, allowedLevel, store, up) {
      var prev = taskId;
      while (store.exists(prev)) {
        var targetLevel = store.calculateItemLevel(store.getItem(prev));
        if ((targetLevel === allowedLevel || targetLevel === (allowedLevel - 1)) && store.getBranchIndex(prev) > -1) {
          break;
        } else {
          prev = up ? store.getPrev(prev) : store.getNext(prev);
        }
      }

      if (store.exists(prev)) {
        if (store.calculateItemLevel(store.getItem(prev)) === allowedLevel) {
          return up ? dropTarget.nextSiblingTarget(dndTaskId, prev, store) : dropTarget.prevSiblingTarget(dndTaskId, prev, store);
        } else {
          return dropTarget.firstChildTarget(dndTaskId, prev, store);
        }
      }
      return null;
    }

    function findTargetAbove(dndTaskId, taskId, allowedLevel, store) {
      return findClosesTarget(dndTaskId, taskId, allowedLevel, store, true);
    }
    function findTargetBelow(dndTaskId, taskId, allowedLevel, store) {
      return findClosesTarget(dndTaskId, taskId, allowedLevel, store, false);
    }

    return function getSameLevelDropPosition(dndTaskId, targetTaskId, relTargetPos, eventTop, store, level) {
      var result;
      if (targetTaskId !== store.$getRootId()) {
        if (relTargetPos < 0.5) {
          if (store.calculateItemLevel(store.getItem(targetTaskId)) === level) {
            if (store.getPrevSibling(targetTaskId)) {
              result = dropTarget.nextSiblingTarget(dndTaskId, store.getPrevSibling(targetTaskId), store);
            } else {
              result = dropTarget.prevSiblingTarget(dndTaskId, targetTaskId, store);
            }
          } else {
            result = findTargetAbove(dndTaskId, targetTaskId, level, store);
            if (result) {
              result = findTargetBelow(dndTaskId, targetTaskId, level, store);
            }
          }
        } else {
          if (store.calculateItemLevel(store.getItem(targetTaskId)) === level) {
            result = dropTarget.nextSiblingTarget(dndTaskId, targetTaskId, store);
          } else {
            result = findTargetBelow(dndTaskId, targetTaskId, level, store);
            if (result) {
              result = findTargetAbove(dndTaskId, targetTaskId, level, store);
            }
          }
        }
      } else {
        var rootId = store.$getRootId();
        var rootLevel = store.getChildren(rootId);
        result = dropTarget.createDropTargetObject();
        if (rootLevel.length && eventTop >= 0) {
          result = findTargetAbove(dndTaskId, getLast(store), level, store);
        } else {
          result = findTargetBelow(dndTaskId, rootId, level, store);
        }
      }

      return result;
    };


    /***/
  }

  multiLevel() {

    /**
     * resolve dnd position of the task when gantt.config.order_branch_free = true
     */

    var dropTarget = this.dropTarget();

    return function getMultiLevelDropPosition(dndTaskId, targetTaskId, relTargetPos, eventTop, store) {
      var result;

      if (targetTaskId !== store.$getRootId()) {
        if (relTargetPos < 0.25) {
          result = dropTarget.prevSiblingTarget(dndTaskId, targetTaskId, store);
        } else if (relTargetPos > 0.60 && !(store.hasChild(targetTaskId) && store.getItem(targetTaskId).$open)) {
          result = dropTarget.nextSiblingTarget(dndTaskId, targetTaskId, store);
        } else {
          result = dropTarget.firstChildTarget(dndTaskId, targetTaskId, store);
        }
      } else {
        var rootId = store.$getRootId();
        if (store.hasChild(rootId) && eventTop >= 0) {
          result = dropTarget.lastChildTarget(dndTaskId, rootId, store);
        } else {
          result = dropTarget.firstChildTarget(dndTaskId, rootId, store);
        }
      }

      return result;
    };

    /***/
  }
}
