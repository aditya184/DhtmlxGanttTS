import { Injectable } from '@angular/core';
import { UtilsService } from 'src/app/services/utils/utils.service';
import { ViewportService } from './viewport/viewport.service';

@Injectable({
  providedIn: 'root'
})
export class RenderService {

  constructor(private utilsService: UtilsService, private viewportService: ViewportService) { }

  isLegacySmartRender() {

  return function(gantt) {
    return gantt.config.smart_rendering && gantt._smart_render;
  };

  /***/
  }

  layerEngine() {

    var renderFactoryProvider = this.renderFactory();
    var utils = this.utilsService.utils(),
      domHelpers = this.utilsService.helpers,
      isLegacyRender = this.isLegacySmartRender();

    var layerFactory = function (gantt) {

      var renderFactory = renderFactoryProvider(gantt);
      return {
        createGroup: function (get_container, rel_root, defaultFilters) {

          var renderGroup = {
            tempCollection: [],
            renderers: {},
            container: get_container,
            filters: [],
            getLayers: function () {
              this._add();// add pending layers

              var res = [];
              for (var i in this.renderers) {
                res.push(this.renderers[i]);
              }
              return res;
            },
            getLayer: function (id) {
              return this.renderers[id];
            },
            _add: function (layer) {
              if (layer) {
                layer.id = layer.id || utils.uid();
                this.tempCollection.push(layer);
              }

              var container = this.container();

              var pending = this.tempCollection;
              for (var i = 0; i < pending.length; i++) {
                layer = pending[i];

                if (!this.container() && !(layer && layer.container && domHelpers.isChildOf(layer.container, document.body))) continue;

                var node = layer.container,
                  id = layer.id,
                  topmost = layer.topmost;
                if (!node.parentNode) {
                  //insert on top or below the tasks
                  if (topmost) {
                    container.appendChild(node);
                  } else {
                    var rel = rel_root ? rel_root() : container.firstChild;
                    if (rel)
                      container.insertBefore(node, rel);
                    else
                      container.appendChild(node);
                  }
                }
                this.renderers[id] = renderFactory.getRenderer(
                  id,
                  layer,
                  node
                );
                this.tempCollection.splice(i, 1);
                i--;
              }
            },
            addLayer: function (config?) {
              //config = prepareConfig(config);
              if (config) {
                if (typeof config == "function") {
                  config = { renderer: config };
                }

                if (config.filter === undefined) {
                  config.filter = mergeFilters(defaultFilters || []);
                } else if (config.filter instanceof Array) {
                  config.filter.push(defaultFilters);
                  config.filter = mergeFilters(config.filter);
                }

                if (!config.container) {
                  config.container = document.createElement("div");
                }
                var self = this;
                config.requestUpdate = function () {
                  if (gantt.config.smart_rendering && !isLegacyRender(gantt)) {
                    if (self.renderers[config.id]) {
                      self.onUpdateRequest(self.renderers[config.id]);
                    }
                  }

                };
              }

              this._add(config);
              return (config ? config.id : undefined);
            },
            onUpdateRequest: function (layer) {

            },

            eachLayer: function (code) {
              for (var i in this.renderers) {
                code(this.renderers[i]);
              }
            },
            removeLayer: function (id) {
              if (!this.renderers[id])
                return;
              this.renderers[id].destructor();
              delete this.renderers[id];
            },
            clear: function () {
              for (var i in this.renderers) {
                this.renderers[i].destructor();
              }
              this.renderers = {};
            }//,
            //prepareConfig: prepareConfig
          };

          gantt.attachEvent("onDestroy", function () {
            renderGroup.clear();
            renderGroup = null;
          });

          return renderGroup;
        }
      };
    };


    function mergeFilters(filter_methods) {
      if (!(filter_methods instanceof Array)) {
        filter_methods = Array.prototype.slice.call(arguments, 0);
      }

      return function (obj) {
        var res = true;
        for (var i = 0, len = filter_methods.length; i < len; i++) {
          var filter_method = filter_methods[i];
          if (filter_method) {
            res = res && (filter_method(obj.id, obj) !== false);
          }
        }

        return res;
      };
    }


    return layerFactory;


    /***/
  }

  linkRender() {

    var smartRender = this.smartRenderWrapper();
    var isLinkInViewPort = this.viewportService.linkChecker()
    var isLegacyRender = this.isLegacySmartRender();

    function createLinkRender(gantt) {

      function _render_link_element(link, view) {
        var config = view.$getConfig();

        var pt = path_builder.get_endpoint(link, view);
        var dy = pt.e_y - pt.y;
        var dx = pt.e_x - pt.x;
        if (!dx && !dy) {
          return null;
        }


        var dots = path_builder.get_points(link, view);
        var lines = drawer.get_lines(dots, view);

        var div = document.createElement("div");

        var css = "gantt_task_link";

        if (link.color) {
          css += " gantt_link_inline_color";
        }
        var cssTemplate = gantt.templates.link_class ? gantt.templates.link_class(link) : "";
        if (cssTemplate) {
          css += " " + cssTemplate;
        }

        if (config.highlight_critical_path && gantt.isCriticalLink) {
          if (gantt.isCriticalLink(link))
            css += " gantt_critical_link";
        }

        div.className = css;

        if (view.$config.link_attribute) {
          div.setAttribute(view.$config.link_attribute, link.id);
        }

        for (var i = 0; i < lines.length; i++) {
          if (i == lines.length - 1) {
            lines[i].size -= config.link_arrow_size;
          }
          var el: any = drawer.render_line(lines[i], lines[i + 1], view);
          if (link.color) {
            el.firstChild.style.backgroundColor = link.color;
          }
          div.appendChild(el);
        }

        var direction = lines[lines.length - 1].direction;
        var endpoint = _render_link_arrow(dots[dots.length - 1], direction, view);
        if (link.color) {
          endpoint.style.borderColor = link.color;
        }
        div.appendChild(endpoint);

        gantt._waiAria.linkAttr(link, div);

        return div;
      }

      function _render_link_arrow(point, direction, view) {
        var config = view.$getConfig();
        var div = document.createElement("div");
        var top = point.y;
        var left = point.x;

        var size = config.link_arrow_size;
        var line_width = config.row_height;
        var className = "gantt_link_arrow gantt_link_arrow_" + direction;
        switch (direction) {
          case drawer.dirs.right:
            top -= (size - line_width) / 2;
            left -= size;
            break;
          case drawer.dirs.left:
            top -= (size - line_width) / 2;
            break;
          case drawer.dirs.up:
            left -= size;
            break;
          case drawer.dirs.down:
            top += size * 2;
            left -= size;
            break;
          default:
            break;
        }
        div.style.cssText = [
          "top:" + top + "px",
          "left:" + left + 'px'].join(';');
        div.className = className;

        return div;
      }


      var drawer = {
        current_pos: null,
        dirs: { "left": 'left', "right": 'right', "up": 'up', "down": 'down' },
        path: [],
        clear: function () {
          this.current_pos = null;
          this.path = [];
        },
        point: function (pos) {
          this.current_pos = gantt.copy(pos);
        },
        get_lines: function (dots,view) {
          this.clear();
          this.point(dots[0]);
          for (var i = 1; i < dots.length; i++) {
            this.line_to(dots[i]);
          }
          return this.get_path();
        },
        line_to: function (pos) {
          var next = gantt.copy(pos);
          var prev = this.current_pos;

          var line = this._get_line(prev, next);
          this.path.push(line);
          this.current_pos = next;
        },
        get_path: function () {
          return this.path;
        },
        get_wrapper_sizes: function (v, view) {
          var config = view.$getConfig();
          var res,
            wrapper_size = config.link_wrapper_width,
            y = v.y + (config.row_height - wrapper_size) / 2;
          switch (v.direction) {
            case this.dirs.left:
              res = {
                top: y,
                height: wrapper_size,
                lineHeight: wrapper_size,
                left: v.x - v.size - wrapper_size / 2,
                width: v.size + wrapper_size
              };
              break;
            case this.dirs.right:
              res = {
                top: y,
                lineHeight: wrapper_size,
                height: wrapper_size,
                left: v.x - wrapper_size / 2,
                width: v.size + wrapper_size
              };
              break;
            case this.dirs.up:
              res = {
                top: y - v.size,
                lineHeight: v.size + wrapper_size,
                height: v.size + wrapper_size,
                left: v.x - wrapper_size / 2,
                width: wrapper_size
              };
              break;
            case this.dirs.down:
              res = {
                top: y /*- wrapper_size/2*/,
                lineHeight: v.size + wrapper_size,
                height: v.size + wrapper_size,
                left: v.x - wrapper_size / 2,
                width: wrapper_size
              };
              break;
            default:
              break;
          }

          return res;
        },
        get_line_sizes: function (v, view) {
          var config = view.$getConfig();
          var res,
            line_size = config.link_line_width,
            wrapper_size = config.link_wrapper_width,
            size = v.size + line_size;
          switch (v.direction) {
            case this.dirs.left:
            case this.dirs.right:
              res = {
                height: line_size,
                width: size,
                marginTop: (wrapper_size - line_size) / 2,
                marginLeft: (wrapper_size - line_size) / 2
              };
              break;
            case this.dirs.up:
            case this.dirs.down:
              res = {
                height: size,
                width: line_size,
                marginTop: (wrapper_size - line_size) / 2,
                marginLeft: (wrapper_size - line_size) / 2
              };
              break;
            default:
              break;
          }


          return res;
        },
        render_line: function (v, end, view) {
          var pos = this.get_wrapper_sizes(v, view);
          var wrapper = document.createElement("div");
          wrapper.style.cssText = [
            "top:" + pos.top + "px",
            "left:" + pos.left + "px",
            "height:" + pos.height + "px",
            "width:" + pos.width + "px"
          ].join(';');
          wrapper.className = "gantt_line_wrapper";

          var innerPos = this.get_line_sizes(v, view);
          var inner = document.createElement("div");
          inner.style.cssText = [
            "height:" + innerPos.height + "px",
            "width:" + innerPos.width + "px",
            "margin-top:" + innerPos.marginTop + "px",
            "margin-left:" + innerPos.marginLeft + "px"
          ].join(";");

          inner.className = "gantt_link_line_" + v.direction;
          wrapper.appendChild(inner);

          return wrapper;
        },
        _get_line: function (from, to) {
          var direction = this.get_direction(from, to);
          var vect: any = {
            x: from.x,
            y: from.y,
            direction: this.get_direction(from, to)
          };
          if (direction == this.dirs.left || direction == this.dirs.right) {
            vect.size = Math.abs(from.x - to.x);
          } else {
            vect.size = Math.abs(from.y - to.y);
          }
          return vect;
        },
        get_direction: function (from, to) {
          var direction = 0;
          if (to.x < from.x) {
            direction = this.dirs.left;
          } else if (to.x > from.x) {
            direction = this.dirs.right;
          } else if (to.y > from.y) {
            direction = this.dirs.down;
          } else {
            direction = this.dirs.up;
          }
          return direction;
        }

      };

      var path_builder = {

        path: [],
        clear: function () {
          this.path = [];
        },
        current: function () {
          return this.path[this.path.length - 1];
        },
        point: function (next) {
          if (!next)
            return this.current();

          this.path.push(gantt.copy(next));
          return next;
        },
        point_to: function (direction, diff, point) {
          if (!point)
            point = gantt.copy(this.point());
          else
            point = { x: point.x, y: point.y };
          var dir = drawer.dirs;
          switch (direction) {
            case (dir.left):
              point.x -= diff;
              break;
            case (dir.right):
              point.x += diff;
              break;
            case (dir.up):
              point.y -= diff;
              break;
            case (dir.down):
              point.y += diff;
              break;
            default:
              break;
          }
          return this.point(point);
        },
        get_points: function (link, view) {
          var pt = this.get_endpoint(link, view);
          var xy = gantt.config;

          var dy = pt.e_y - pt.y;
          var dx = pt.e_x - pt.x;

          var dir = drawer.dirs;

          this.clear();
          this.point({ x: pt.x, y: pt.y });

          var shiftX = 2 * xy.link_arrow_size;//just random size for first line
          var lineType = this.get_line_type(link, view.$getConfig());

          var forward = (pt.e_x > pt.x);
          if (lineType.from_start && lineType.to_start) {
            this.point_to(dir.left, shiftX);
            if (forward) {
              this.point_to(dir.down, dy);
              this.point_to(dir.right, dx);
            } else {
              this.point_to(dir.right, dx);
              this.point_to(dir.down, dy);
            }
            this.point_to(dir.right, shiftX);

          } else if (!lineType.from_start && lineType.to_start) {
            forward = (pt.e_x > (pt.x + 2 * shiftX));
            this.point_to(dir.right, shiftX);
            if (forward) {
              dx -= shiftX;
              this.point_to(dir.down, dy);
              this.point_to(dir.right, dx);
            } else {
              dx -= 2 * shiftX;
              var sign = dy > 0 ? 1 : -1;

              this.point_to(dir.down, sign * (xy.row_height / 2));
              this.point_to(dir.right, dx);
              this.point_to(dir.down, sign * (Math.abs(dy) - (xy.row_height / 2)));
              this.point_to(dir.right, shiftX);
            }

          } else if (!lineType.from_start && !lineType.to_start) {
            this.point_to(dir.right, shiftX);
            if (forward) {
              this.point_to(dir.right, dx);
              this.point_to(dir.down, dy);
            } else {
              this.point_to(dir.down, dy);
              this.point_to(dir.right, dx);
            }
            this.point_to(dir.left, shiftX);
          } else if (lineType.from_start && !lineType.to_start) {

            forward = (pt.e_x > (pt.x - 2 * shiftX));
            this.point_to(dir.left, shiftX);

            if (!forward) {
              dx += shiftX;
              this.point_to(dir.down, dy);
              this.point_to(dir.right, dx);
            } else {
              dx += 2 * shiftX;
              var sign = dy > 0 ? 1 : -1;
              this.point_to(dir.down, sign * (xy.row_height / 2));
              this.point_to(dir.right, dx);
              this.point_to(dir.down, sign * (Math.abs(dy) - (xy.row_height / 2)));
              this.point_to(dir.left, shiftX);
            }

          }

          return this.path;
        },
        get_line_type: function (link, config) {
          var types = config.links;
          var from_start = false, to_start = false;
          if (link.type == types.start_to_start) {
            from_start = to_start = true;
          } else if (link.type == types.finish_to_finish) {
            from_start = to_start = false;
          } else if (link.type == types.finish_to_start) {
            from_start = false;
            to_start = true;
          } else if (link.type == types.start_to_finish) {
            from_start = true;
            to_start = false;
          } else {
            gantt.assert(false, "Invalid link type");
          }

          if (config.rtl) {
            from_start = !from_start;
            to_start = !to_start;
          }

          return { from_start: from_start, to_start: to_start };
        },

        get_endpoint: function (link, view) {
          var config = view.$getConfig();

          var lineType = this.get_line_type(link, config);
          var from_start = lineType.from_start,
            to_start = lineType.to_start;

          var source = gantt.getTask(link.source);
          var target = gantt.getTask(link.target);

          var from = getMilestonePosition(source, view),
            to = getMilestonePosition(target, view);

          return {
            x: from_start ? from.left : (from.left + from.width),
            e_x: to_start ? to.left : (to.left + to.width),
            y: from.top,
            e_y: to.top
          };
        }
      };

      function getMilestonePosition(task, view) {
        var config = view.$getConfig();
        var pos = view.getItemPosition(task);
        if (gantt.getTaskType(task.type) == config.types.milestone) {
          var milestoneHeight = gantt.getTaskHeight();
          var milestoneWidth = Math.sqrt(2 * milestoneHeight * milestoneHeight);
          pos.left -= milestoneWidth / 2;
          pos.width = milestoneWidth;
        }
        return pos;
      }

      return smartRender(
        _render_link_element,
        function () { },
        isLinkInViewPort,
        gantt.config.smart_rendering && !isLegacyRender(gantt)
      );
    }

    return createLinkRender;

    /***/
  }

  renderFactory() {

    var rendererFactory = function (gantt) {
      var services = gantt.$services;

      //hash of dom elements is needed to redraw single bar/link
      var task_area_pulls = {},
        task_area_renderers = {};

      function getRenderer(id, layer?, node?) {

        if (task_area_renderers[id])
          return task_area_renderers[id];

        if (!layer.renderer)
          gantt.assert(false, "Invalid renderer call");

        var renderMethod = null;
        var updateMethod = null;

        if (typeof layer.renderer === "function") {
          renderMethod = layer.renderer;
        } else {
          renderMethod = layer.renderer.render;
          updateMethod = layer.renderer.update;
        }

        var renderOne = function (item, viewPort) {
          var rendererViewPort = viewPort;
          if (!rendererViewPort && layer.getViewPort) {
            rendererViewPort = layer.getViewPort();
          }
          return renderMethod.call(this, item, layer.host, rendererViewPort || null);
        };

        var filter = layer.filter;

        if (node)
          node.setAttribute(services.config().layer_attribute, true);

        task_area_renderers[id] = {
          render_item: function (item, container, viewPort) {
            container = container || node;

            if (filter) {
              if (!filter(item)) {
                this.remove_item(item.id);
                return;
              }
            }

            var dom = renderOne.call(gantt, item, viewPort);
            this.append(item, dom, container);

          },

          clear: function (container) {

            this.rendered = task_area_pulls[id] = {};
            if (!layer.append)
              this.clear_container(container);
          },
          clear_container: function (container) {
            container = container || node;
            if (container)
              container.innerHTML = "";
          },
          render_items: function (items, container) {
            container = container || node;

            var buffer = document.createDocumentFragment();
            this.clear(container);
            var viewPort = null;
            if (layer.getViewPort) {
              viewPort = layer.getViewPort();
            }
            for (var i = 0, vis = items.length; i < vis; i++) {
              this.render_item(items[i], buffer, viewPort);
            }

            container.appendChild(buffer, container);
          },
          update_items: function (items, container) {
            container = container || node;
            if (!updateMethod) {
              return;
            }

            var buffer = document.createDocumentFragment();
            var viewPort = null;
            if (layer.getViewPort) {
              viewPort = layer.getViewPort();
            }

            for (var i = 0, vis = items.length; i < vis; i++) {
              var item = items[i];
              var itemNode = this.rendered[item.id];
              if (itemNode && itemNode.parentNode) {
                updateMethod.call(gantt, item, layer.host, this, viewPort);
              } else {
                this.render_item(items[i], buffer, viewPort);
              }


            }
            if (buffer.childNodes.length) {
              container.appendChild(buffer, container);
            }
          },
          append: function (item, node, container) {
            if (!node) {
              if (this.rendered[item.id]) {
                this.remove_item(item.id);
              }
              return;
            }

            if (this.rendered[item.id] && this.rendered[item.id].parentNode) {
              this.replace_item(item.id, node);
            } else {
              container.appendChild(node);
            }
            this.rendered[item.id] = node;

          },
          replace_item: function (item_id, newNode) {
            var item = this.rendered[item_id];
            if (item && item.parentNode) {
              item.parentNode.replaceChild(newNode, item);
            }
            this.rendered[item_id] = newNode;
          },
          remove_item: function (item_id) {
            this.hide(item_id);
            delete this.rendered[item_id];
          },
          hide: function (item_id) {
            var item = this.rendered[item_id];
            if (item && item.parentNode) {
              item.parentNode.removeChild(item);
            }
          },
          restore: function (item) {
            var dom = this.rendered[item.id];
            if (dom) {
              if (!dom.parentNode) {
                this.append(item, dom, node);
              }
            } else {
              this.render_item(item, node);
            }
          },
          change_id: function (oldid, newid) {
            this.rendered[newid] = this.rendered[oldid];
            delete this.rendered[oldid];
          },
          rendered: task_area_pulls[id],
          node: node,
          destructor: function () {
            this.clear();
            delete task_area_renderers[id];
            delete task_area_pulls[id];
          }
        };

        return task_area_renderers[id];
      }


      function clearRenderers() {
        for (var i in task_area_renderers) {
          getRenderer(i).destructor();
        }
      }

      return {
        getRenderer: getRenderer,
        clearRenderers: clearRenderers
      };

    };

    return rendererFactory;

    /***/
  }

  smartRenderWrapper() {

    return function wrapSmartRender(renderOne, updateOne, isInViewPort, smartRendering) {
      if (!smartRendering) {
        return renderOne;
      } else {
        return {
          render: function (item, view, viewport) {
            if (!isInViewPort.call(this, item, view, viewport)) {
              return null;
            }
            return renderOne.call(this, item, view, viewport);
          },
          update: function (item, view, engine, viewport) {
            if (!isInViewPort.call(this, item, view, viewport)) {
              engine.hide(item.id);
            } else if (engine.rendered[item.id]) {
              updateOne.call(this, item, view, engine, viewport);
              engine.restore(item);
            } else {
              renderOne.call(this, item, view, viewport);
            }
          }
        };
      }


    };

    /***/
  }

  taskBarRender() {

    function createTaskRenderer(gantt) {

      function _render_task_element(task, view) {
        var config = view.$getConfig();
        var painters = config.type_renderers;
        var renderer = painters[gantt.getTaskType(task.type)],
          defaultRenderer = _task_default_render;

        if (!renderer) {
          return defaultRenderer.call(gantt, task, view);
        } else {
          return renderer.call(gantt, task, function (task) { return defaultRenderer.call(gantt, task, view); }, view);
        }
      }

      function _task_default_render(task, view) {
        if (gantt._isAllowedUnscheduledTask(task))
          return;


        var pos = view.getItemPosition(task);

        var cfg = view.$getConfig(),
          templates = view.$getTemplates();
        var height = view.getItemHeight();

        var taskType = gantt.getTaskType(task.type);

        var padd = Math.floor((gantt.config.row_height - height) / 2);
        if (taskType == cfg.types.milestone && cfg.link_line_width > 1) {
          //little adjust milestone position, so horisontal corners would match link arrow when thickness of link line is more than 1px
          padd += 1;
        }

        if (taskType == cfg.types.milestone) {
          pos.left -= Math.round(height / 2);
          pos.width = height;
        }

        var div = document.createElement("div");

        var width = Math.round(pos.width);

        if (view.$config.item_attribute) {
          div.setAttribute(view.$config.item_attribute, task.id);
        }

        if (cfg.show_progress && taskType != cfg.types.milestone) {
          _render_task_progress(task, div, width, cfg, templates);
        }

        //use separate div to display content above progress bar
        var content = _render_task_content(task, width, templates);
        if (task.textColor) {
          content.style.color = task.textColor;
        }
        div.appendChild(content);

        var css = _combine_item_class("gantt_task_line",
          templates.task_class(task.start_date, task.end_date, task),
          task.id,
          view);
        if (task.color || task.progressColor || task.textColor) {
          css += " gantt_task_inline_color";
        }
        div.className = css;

        var styles = [
          "left:" + pos.left + "px",
          "top:" + (padd + pos.top) + 'px',
          "height:" + height + 'px',
          "line-height:" + (Math.max(height < 30 ? height - 2 : height, 0)) + 'px',
          "width:" + width + 'px'
        ];
        if (task.color) {
          styles.push("background-color:" + task.color);
        }
        if (task.textColor) {
          styles.push("color:" + task.textColor);
        }

        div.style.cssText = styles.join(";");
        var side = _render_leftside_content(task, cfg, templates);
        if (side) div.appendChild(side);

        side = _render_rightside_content(task, cfg, templates);
        if (side) div.appendChild(side);

        gantt._waiAria.setTaskBarAttr(task, div);

        var state = gantt.getState();

        if (!gantt.isReadonly(task)) {
          if (cfg.drag_resize && !gantt.isSummaryTask(task) && taskType != cfg.types.milestone) {
            _render_pair(div, "gantt_task_drag", task, function (css) {
              var el = document.createElement("div");
              el.className = css;
              return el;
            }, cfg);
          }
          if (cfg.drag_links && cfg.show_links) {
            _render_pair(div, "gantt_link_control", task, function (css) {
              var outer = document.createElement("div");
              outer.className = css;
              outer.style.cssText = [
                "height:" + height + 'px',
                "line-height:" + height + 'px'
              ].join(";");
              var inner = document.createElement("div");
              inner.className = "gantt_link_point";

              var showLinkPoints = false;
              if (state.link_source_id && cfg.touch) {
                showLinkPoints = true;
              }

              inner.style.display = showLinkPoints ? "block" : "";
              outer.appendChild(inner);
              return outer;
            }, cfg);
          }
        }
        return div;
      }

      function _render_side_content(task, template, cssClass) {
        if (!template) return null;

        var text = template(task.start_date, task.end_date, task);
        if (!text) return null;
        var content = document.createElement("div");
        content.className = "gantt_side_content " + cssClass;
        content.innerHTML = text;
        return content;
      }

      function _render_leftside_content(task, cfg, templates) {
        var css = "gantt_left " + _get_link_crossing_css(!cfg.rtl ? true : false, task, cfg);
        return _render_side_content(task, templates.leftside_text, css);
      }

      function _render_rightside_content(task, cfg, templates) {
        var css = "gantt_right " + _get_link_crossing_css(!cfg.rtl ? false : true, task, cfg);
        return _render_side_content(task, templates.rightside_text, css);
      }

      function _get_link_crossing_css(left, task, config) {
        var cond = _get_conditions(left);

        for (var i in cond) {
          var links = task[i];
          for (var ln = 0; ln < links.length; ln++) {
            var link = gantt.getLink(links[ln]);

            for (var tp = 0; tp < cond[i].length; tp++) {
              if (link.type == cond[i][tp]) {
                return "gantt_link_crossing";
              }
            }
          }
        }
        return "";
      }


      function _render_task_content(task, width, templates) {
        var content = document.createElement("div");
        if (gantt.getTaskType(task.type) != gantt.config.types.milestone)
          content.innerHTML = templates.task_text(task.start_date, task.end_date, task);
        content.className = "gantt_task_content";
        //content.style.width = width + 'px';
        return content;
      }

      function _render_task_progress(task, element, maxWidth, cfg, templates) {
        var done = task.progress * 1 || 0;

        maxWidth = Math.max(maxWidth - 2, 0);//2px for borders
        var pr: any = document.createElement("div");
        var width = Math.round(maxWidth * done);

        width = Math.min(maxWidth, width);
        if (task.progressColor) {
          pr.style.backgroundColor = task.progressColor;
          pr.style.opacity = 1;
        }
        pr.style.width = width + 'px';
        pr.className = "gantt_task_progress";
        pr.innerHTML = templates.progress_text(task.start_date, task.end_date, task);

        if (cfg.rtl) {
          pr.style.position = "absolute";
          pr.style.right = "0px";
        }

        var wrapper = document.createElement("div");
        wrapper.className = "gantt_task_progress_wrapper";
        wrapper.appendChild(pr);
        element.appendChild(wrapper);

        if (gantt.config.drag_progress && !gantt.isReadonly(task)) {
          var drag = document.createElement("div");

          var markerPos = width;
          if (cfg.rtl) {
            markerPos = maxWidth - width;
          }

          drag.style.left = markerPos + 'px';
          drag.className = "gantt_task_progress_drag";
          pr.appendChild(drag);
          element.appendChild(drag);
        }
      }

      function _get_conditions(leftside) {
        if (leftside) {
          return {
            $source: [
              gantt.config.links.start_to_start
            ],
            $target: [
              gantt.config.links.start_to_start,
              gantt.config.links.finish_to_start
            ]
          };
        } else {
          return {
            $source: [
              gantt.config.links.finish_to_start,
              gantt.config.links.finish_to_finish
            ],
            $target: [
              gantt.config.links.finish_to_finish
            ]
          };
        }
      }

      function _combine_item_class(basic, template, itemId, view) {
        var cfg = view.$getConfig();
        var css = [basic];
        if (template)
          css.push(template);

        var state = gantt.getState();

        var task = gantt.getTask(itemId);

        if (gantt.getTaskType(task.type) == cfg.types.milestone) {
          css.push("gantt_milestone");
        } else if (gantt.getTaskType(task.type) == cfg.types.project) {
          css.push("gantt_project");
        }

        css.push("gantt_bar_" + gantt.getTaskType(task.type));


        if (gantt.isSummaryTask(task))
          css.push("gantt_dependent_task");

        if (gantt.isSplitTask(task) && ((cfg.open_split_tasks && !task.$open) || !cfg.open_split_tasks)) {
          css.push("gantt_split_parent");
        }

        if (cfg.select_task && gantt.isSelectedTask(itemId)) {
          css.push("gantt_selected");
        }

        if (itemId == state.drag_id) {
          css.push("gantt_drag_" + state.drag_mode);
          if (state.touch_drag) {
            css.push("gantt_touch_" + state.drag_mode);
          }
        }

        if (state.link_source_id == itemId)
          css.push("gantt_link_source");

        if (state.link_target_id == itemId)
          css.push("gantt_link_target");


        if (cfg.highlight_critical_path && gantt.isCriticalTask) {
          if (gantt.isCriticalTask(task))
            css.push("gantt_critical_task");
        }

        if (state.link_landing_area &&
          (state.link_target_id && state.link_source_id) &&
          (state.link_target_id != state.link_source_id)) {

          var from_id = state.link_source_id;
          var from_start = state.link_from_start;
          var to_start = state.link_to_start;

          var allowDrag = gantt.isLinkAllowed(from_id, itemId, from_start, to_start);

          var dragClass = "";
          if (allowDrag) {
            if (to_start)
              dragClass = "link_start_allow";
            else
              dragClass = "link_finish_allow";
          } else {
            if (to_start)
              dragClass = "link_start_deny";
            else
              dragClass = "link_finish_deny";
          }
          css.push(dragClass);
        }
        return css.join(" ");
      }

      function _render_pair(parent, css, task, content, config) {
        var state = gantt.getState();
        var className, element;
        if (+task.start_date >= +state.min_date) {
          className = [css, config.rtl ? "task_right" : "task_left", "task_start_date"];
          element = content(className.join(" "));
          element.setAttribute("data-bind-property", "start_date");
          parent.appendChild(element);
        }

        if (+task.end_date <= +state.max_date) {
          className = [css, config.rtl ? "task_left" : "task_right", "task_end_date"];
          element = content(className.join(" "));
          element.setAttribute("data-bind-property", "end_date");
          parent.appendChild(element);
        }

      }

      return _render_task_element;
    }

    return createTaskRenderer;

    /***/
  }

  taskBarSmartRender() {

    var smartRender = this.smartRenderWrapper();
    var isBarInViewPort = this.viewportService.taskBarChecker();
    var createBaseBarRender = this.taskBarRender();
    var isLegacyRender = this.isLegacySmartRender();
    return function createTaskRenderer(gantt) {
      var defaultRender = createBaseBarRender(gantt);

      return smartRender(
        defaultRender,
        function () { },
        isBarInViewPort,
        gantt.config.smart_rendering && !isLegacyRender(gantt)
      );
    };

    /***/
  }

  taskBgRender() {

    var smartRender = this.smartRenderWrapper();
    var isRowInViewPort = this.viewportService.task_rowChecker();
    var isLegacyRender = this.isLegacySmartRender();
    function getIndexRange(scale, viewportLeft, viewPortRight) {
      var firstCellIndex = 0;
      var lastCellIndex = scale.left.length - 1;
      for (var i = 0; i < scale.left.length; i++) {
        var left = scale.left[i];
        if (left < viewportLeft) {
          firstCellIndex = i;
        }
        if (left > viewPortRight) {
          lastCellIndex = i;
          break;
        }
      }
      return {
        start: firstCellIndex,
        end: lastCellIndex
      };
    }

    function createTaskBgRender(gantt) {
      var renderedCells = {};
      var visibleCells = {};

      function isRendered(item, columnIndex) {
        if (renderedCells[item.id][columnIndex] && renderedCells[item.id][columnIndex].parentNode) {
          return true;
        } else {
          return false;
        }
      }

      function detachRenderedCell(itemId, columnIndex) {
        if (renderedCells[itemId] && renderedCells[itemId][columnIndex] &&
          renderedCells[itemId][columnIndex].parentNode
        ) {
          renderedCells[itemId][columnIndex].parentNode.removeChild(renderedCells[itemId][columnIndex]);
        }
      }

      function getCellTemplate(view) {
        var templates = view.$getTemplates();
        var cssTemplate;
        if (typeof templates.task_cell_class !== "undefined") {
          cssTemplate = templates.task_cell_class;
          // eslint-disable-next-line no-console
          var log = console.warn || console.log;
          log('gantt.templates.task_cell_class template is deprecated and will be removed soon. Please use gantt.templates.timeline_cell_class instead.');
        } else {
          cssTemplate = templates.timeline_cell_class;
        }
        return cssTemplate;
      }

      function renderCells(item, view, engine, viewPort) {
        var config = view.$getConfig();
        var cfg = view.getScale();
        var count = cfg.count;
        var cssTemplate = getCellTemplate(view);

        if (config.show_task_cells) {
          if (!renderedCells[item.id]) {
            renderedCells[item.id] = {};
          }
          if (!visibleCells[item.id]) {
            visibleCells[item.id] = {};
          }

          var range = getIndexRange(cfg, viewPort.x, viewPort.x_end);

          var row = engine.rendered[item.id];

          for (var i in visibleCells[item.id]) {
            var index = visibleCells[item.id][i];

            if (Number(index) < range.start || Number(index) > range.end) {
              detachRenderedCell(item.id, index);
            }
          }
          visibleCells[item.id][columnIndex] = {};

          // TODO: do not iterate all cell, only ones in the viewport and once that are already rendered
          for (var columnIndex = range.start; columnIndex <= range.end; columnIndex++) {
            var cell = renderOneCell(cfg, columnIndex, item, viewPort, count, cssTemplate, config);
            if (!cell && isRendered(item, columnIndex)) {
              detachRenderedCell(item.id, columnIndex);
            } else if (cell && !cell.parentNode) {
              row.appendChild(cell);
            }
          }
        }
      }

      function isColumnVisible(columnIndex, scale, viewPort) {
        var width = scale.width[columnIndex];
        if (width <= 0) {
          return false;
        }
        if (!gantt.config.smart_rendering || isLegacyRender(gantt)) {
          return true;
        }
        var cellLeftCoord = scale.left[columnIndex] - width;
        var cellRightCoord = scale.left[columnIndex] + width;
        return (cellLeftCoord <= viewPort.x_end && cellRightCoord >= viewPort.x);//do not render skipped columns
      }

      function renderOneCell(scale, columnIndex, item, viewPort, count, cssTemplate, config) {
        var width = scale.width[columnIndex],
          cssclass = "";

        if (isColumnVisible(columnIndex, scale, viewPort)) {//do not render skipped columns

          var cssTemplateContent = cssTemplate(item, scale.trace_x[columnIndex]);

          if (config.static_background) {
            // if cell render in static background is not allowed, or if it's a blank cell
            if (!(config.static_background_cells && cssTemplateContent)) {
              return null;
            }
          }

          if (renderedCells[item.id][columnIndex]) {
            visibleCells[item.id][columnIndex] = columnIndex;
            return renderedCells[item.id][columnIndex];
          }
          var cell = document.createElement("div");
          cell.style.width = (width) + "px";

          cssclass = "gantt_task_cell" + (columnIndex == count - 1 ? " gantt_last_cell" : "");
          if (cssTemplateContent) {
            cssclass += " " + cssTemplateContent;
          }
          cell.className = cssclass;

          if (gantt.config.smart_rendering) {
            cell.style.position = "absolute";
            cell.style.left = scale.left[columnIndex] + "px";
            renderedCells[item.id][columnIndex] = cell;
            visibleCells[item.id][columnIndex] = columnIndex;
          }
          return cell;
        }
        return null;
      }

      function _render_bg_line(item, view, viewPort) {
        var config = view.$getConfig(),
          templates = view.$getTemplates();
        var cfg = view.getScale();
        var count = cfg.count;

        if (config.static_background && !config.static_background_cells) {
          return null;
        }

        var row = document.createElement("div");

        var cellTemplate = getCellTemplate(view);

        var range = getIndexRange(cfg, viewPort.x, viewPort.x_end);

        if (!config.smart_rendering || isLegacyRender(gantt)) {
          range = {
            start: 0,
            end: count - 1
          };
        }
        if (config.show_task_cells) {
          renderedCells[item.id] = {};
          visibleCells[item.id] = {};
          for (var columnIndex = range.start; columnIndex <= range.end; columnIndex++) {
            var cell = renderOneCell(cfg, columnIndex, item, viewPort, count, cellTemplate, config);
            if (cell) {
              row.appendChild(cell);
            }
          }
        }
        var odd = gantt.getGlobalTaskIndex(item.id) % 2 !== 0;
        var cssTemplate = templates.task_row_class(item.start_date, item.end_date, item);
        var css = "gantt_task_row" + (odd ? " odd" : "") + (cssTemplate ? ' ' + cssTemplate : '');

        var store = view.$config.rowStore;
        if (store.isSelected(item.id)) {
          css += " gantt_selected";
        }

        row.className = css;

        if (config.smart_rendering) {
          row.style.position = "absolute";
          row.style.top = view.getItemTop(item.id) + "px";
          row.style.width = "100%";
        }
        row.style.height = (config.row_height) + "px";

        if (view.$config.item_attribute) {
          row.setAttribute(view.$config.item_attribute, item.id);
        }

        return row;
      }

      return smartRender(
        _render_bg_line,
        renderCells,
        isRowInViewPort,
        gantt.config.smart_rendering && !isLegacyRender(gantt)
      );
    }

    return createTaskBgRender;


    /***/
  }

  taskGridLineRender() {

    var helpers = this.utilsService.helpers;
    var smartRender = this.smartRenderWrapper();
    var isRowInViewPort = this.viewportService.task_rowChecker();
    var isLegacyRender = this.isLegacySmartRender();
    function createGridLineRender(gantt) {

      function isInViewPort(item, view, viewport) {
        if (gantt.$keyboardNavigation && gantt.$keyboardNavigation.dispatcher.isTaskFocused(item.id)) {
          return true;
        }

        return isRowInViewPort(item, view, viewport);
      }

      function _render_grid_item(item, view, viewport) {
        var columns = view.getGridColumns();
        var config = view.$getConfig(),
          templates = view.$getTemplates();

        var store = view.$config.rowStore;

        if (config.rtl) {
          columns = columns.reverse();
        }

        var cells = [];
        var has_child;
        for (var i = 0; i < columns.length; i++) {
          var last = i == columns.length - 1;
          var col = columns[i];
          var cell;

          var value;
          var textValue;
          if (col.name == "add") {
            var aria = gantt._waiAria.gridAddButtonAttrString(col);

            value = "<div " + aria + " class='gantt_add'></div>";
            textValue = "";
          } else {
            if (col.template)
              value = col.template(item);
            else
              value = item[col.name];

            if (helpers.isDate(value))
              value = templates.date_grid(value, item);

            if (value === null || value === undefined) {
              value = "";
            }

            textValue = value;
            value = "<div class='gantt_tree_content'>" + value + "</div>";
          }
          var css = "gantt_cell" + (last ? " gantt_last_cell" : "");

          var tree = [];
          if (col.tree) {
            for (var j = 0; j < item.$level; j++)
              tree.push(templates.grid_indent(item));

            has_child = store.hasChild(item.id) && !(gantt.isSplitTask(item) && !gantt.config.open_split_tasks);
            if (has_child) {
              tree.push(templates.grid_open(item));
              tree.push(templates.grid_folder(item));
            } else {
              tree.push(templates.grid_blank(item));
              tree.push(templates.grid_file(item));
            }
          }
          var style = "width:" + (col.width - (last ? 1 : 0)) + "px;";
          if (this.defined(col.align))
            style += "text-align:" + col.align + ";";

          var aria = gantt._waiAria.gridCellAttrString(col, textValue);

          tree.push(value);
          if (config.rtl) {
            tree = tree.reverse();
          }
          cell = "<div class='" + css + "' data-column-index='" + i + "' data-column-name='" + col.name + "' style='" + style + "' " + aria + ">" + tree.join("") + "</div>";
          cells.push(cell);
        }
        var css = gantt.getGlobalTaskIndex(item.id) % 2 === 0 ? "" : " odd";
        css += (item.$transparent) ? " gantt_transparent" : "";

        css += (item.$dataprocessor_class ? " " + item.$dataprocessor_class : "");

        if (templates.grid_row_class) {
          var css_template = templates.grid_row_class.call(gantt, item.start_date, item.end_date, item);
          if (css_template)
            css += " " + css_template;
        }

        if (store.isSelected(item.id)) {
          css += " gantt_selected";
        }

        var el = document.createElement("div");
        el.className = "gantt_row" + css + " gantt_row_" + gantt.getTaskType(item.type);
        var height = view.getItemHeight();
        el.style.height = height + "px";
        el.style.lineHeight = height + "px";

        if (config.smart_rendering) {
          el.style.position = "absolute";
          el.style.left = "0px";
          el.style.top = view.getItemTop(item.id) + "px";
        }

        if (view.$config.item_attribute) {
          el.setAttribute(view.$config.item_attribute, item.id);
        }

        gantt._waiAria.taskRowAttr(item, el);

        el.innerHTML = cells.join("");
        return el;
      }

      //return _render_grid_item;

      return smartRender(
        _render_grid_item,
        function () { },
        isInViewPort,
        gantt.config.smart_rendering && !isLegacyRender(gantt)
      );
    }

    return createGridLineRender;



    /***/
  }

  taskSplitRender() {

    var smartRender = this.smartRenderWrapper();
    var isBarInViewPort = this.viewportService.taskBarChecker();;
    var createBaseBarRender = this.taskBarRender();
    var isLegacyRender = this.isLegacySmartRender();
    function createTaskRenderer(gantt) {
      var defaultRender = createBaseBarRender(gantt);

      function renderSplitTask(task, timeline) {
        if (gantt.isSplitTask(task) && ((gantt.config.open_split_tasks && !task.$open) || !gantt.config.open_split_tasks)) {
          var el = document.createElement('div'),
            sizes = gantt.getTaskPosition(task);

          var sub_tasks = gantt.getChildren(task.id);


          for (var i = 0; i < sub_tasks.length; i++) {
            var child = gantt.getTask(sub_tasks[i]);

            var element = defaultRender(child, timeline);
            if (!element)
              continue;

            var padding = Math.floor((gantt.config.row_height - sizes.height) / 2);

            element.style.top = (sizes.top + padding) + "px";
            element.className += " gantt_split_child";

            el.appendChild(element);
          }
          return el;
        }
        return false;
      }

      return smartRender(
        renderSplitTask,
        function () { },
        isBarInViewPort,
        gantt.config.smart_rendering && !isLegacyRender(gantt)
      );
    }

    return createTaskRenderer;

    /***/
  }
}
