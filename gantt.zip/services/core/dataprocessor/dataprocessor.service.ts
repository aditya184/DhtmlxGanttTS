import { Injectable } from '@angular/core';
import { UtilsService } from '../../utils/utils.service';

@Injectable({
  providedIn: 'root'
})
export class DataprocessorService {

  constructor(private utilsService: UtilsService) { }

  dataProcessor() {

    // "use strict";

    // Object.defineProperty(exports, "__esModule", { value: true });

    var eventable = this.utilsService.eventable();
    var helpers = this.utilsService.helpers;
    var utils = this.utilsService.utils();
    var data_processor_events_1 = this.dataProcessorEvents();
    var extend_gantt_1 = this.extendGantt();
    function createDataProcessor(config) {
      var router;
      var tMode;
      if (config instanceof Function) {
        router = config;
      }
      else if (config.hasOwnProperty("router")) {
        router = config.router;
      }
      else if (config.hasOwnProperty("link") && config.hasOwnProperty("task")) {
        router = config;
      }
      if (router) {
        tMode = "CUSTOM";
      }
      else {
        tMode = config.mode || "REST-JSON";
      }
      var gantt = this; // tslint:disable-line
      var dp = new DataProcessor(config.url);
      dp.init(gantt);
      dp.setTransactionMode({
        mode: tMode,
        router: router
      }, config.batchUpdate);
      return dp;
    }
    return { createDataProcessor : createDataProcessor };
    var DataProcessor = /** @class */ (function () {
      function DataProcessor(serverProcessorURL) {
        this.serverProcessor = serverProcessorURL;
        this.action_param = "!nativeeditor_status";
        this.object = null;
        this.updatedRows = []; // ids of updated rows
        this.autoUpdate = true;
        this.updateMode = "cell";
        this._headers = null;
        this._payload = null;
        this._postDelim = "_";
        this._waitMode = 0;
        this._in_progress = {}; // ?
        this._invalid = {};
        this.mandatoryFields = [];
        this.messages = [];
        this.styles = {
          updated: "font-weight:bold;",
          inserted: "font-weight:bold;",
          deleted: "text-decoration : line-through;",
          invalid: "background-color:FFE0E0;",
          invalid_cell: "border-bottom:2px solid red;",
          error: "color:red;",
          clear: "font-weight:normal;text-decoration:none;"
        };
        this.enableUTFencoding(true);
        eventable(this);
      }
      DataProcessor.prototype.setTransactionMode = function (mode, total) {
        if (typeof mode === "object") {
          this._tMode = mode.mode || this._tMode;
          if (utils.defined(mode.headers)) {
            this._headers = mode.headers;
          }
          if (utils.defined(mode.payload)) {
            this._payload = mode.payload;
          }
        }
        else {
          this._tMode = mode;
          this._tSend = total;
        }
        if (this._tMode === "REST") {
          this._tSend = false;
          this._endnm = true;
        }
        if (this._tMode === "JSON" || this._tMode === "REST-JSON") {
          this._tSend = false;
          this._endnm = true;
          this._serializeAsJson = true;
          this._headers = this._headers || {};
          this._headers["Content-type"] = "application/json";
        }
        if (this._tMode === "CUSTOM") {
          this._tSend = false;
          this._endnm = true;
          this._router = mode.router;
        }
      };
      DataProcessor.prototype.escape = function (data) {
        if (this._utf) {
          return encodeURIComponent(data);
        }
        else {
          return escape(data);
        }
      };
      /**
       * @desc: allows to set escaping mode
       * @param: true - utf based escaping, simple - use current page encoding
       * @type: public
       */
      DataProcessor.prototype.enableUTFencoding = function (mode) {
        this._utf = !!mode;
      };
      /**
       * @desc: allows to define, which column may trigger update
       * @param: val - array or list of true/false values
       * @type: public
       */
      DataProcessor.prototype.setDataColumns = function (val) {
        this._columns = (typeof val === "string") ? val.split(",") : val;
      };
      /**
       * @desc: get state of updating
       * @returns:   true - all in sync with server, false - some items not updated yet.
       * @type: public
       */
      DataProcessor.prototype.getSyncState = function () {
        return !this.updatedRows.length;
      };
      /**
       * @desc: enable/disable named field for data syncing, will use column ids for grid
       * @param:   mode - true/false
       * @type: public
       */
      DataProcessor.prototype.enableDataNames = function (mode) {
        this._endnm = !!mode;
      };
      /**
       * @desc: enable/disable mode , when only changed fields and row id send to the server side, instead of all fields in default mode
       * @param:   mode - true/false
       * @type: public
       */
      DataProcessor.prototype.enablePartialDataSend = function (mode) {
        this._changed = !!mode;
      };
      /**
       * @desc: set if rows should be send to server automaticaly
       * @param: mode - "row" - based on row selection changed, "cell" - based on cell editing finished, "off" - manual data sending
       * @type: public
       */
      DataProcessor.prototype.setUpdateMode = function (mode, dnd) {
        this.autoUpdate = (mode === "cell");
        this.updateMode = mode;
        this.dnd = dnd;
      };
      DataProcessor.prototype.ignore = function (code, master) {
        this._silent_mode = true;
        code.call(master || window);
        this._silent_mode = false;
      };
      /**
       * @desc: mark row as updated/normal. check mandatory fields,initiate autoupdate (if turned on)
       * @param: rowId - id of row to set update-status for
       * @param: state - true for "updated", false for "not updated"
       * @param: mode - update mode name
       * @type: public
       */
      DataProcessor.prototype.setUpdated = function (rowId, state, mode) {
        if (this._silent_mode) {
          return;
        }
        var ind = this.findRow(rowId);
        mode = mode || "updated";
        var existing = this.$gantt.getUserData(rowId, this.action_param);
        if (existing && mode === "updated") {
          mode = existing;
        }
        if (state) {
          this.set_invalid(rowId, false); // clear previous error flag
          this.updatedRows[ind] = rowId;
          this.$gantt.setUserData(rowId, this.action_param, mode);
          if (this._in_progress[rowId]) {
            this._in_progress[rowId] = "wait";
          }
        }
        else {
          if (!this.is_invalid(rowId)) {
            this.updatedRows.splice(ind, 1);
            this.$gantt.setUserData(rowId, this.action_param, "");
          }
        }
        this.markRow(rowId, state, mode);
        if (state && this.autoUpdate) {
          this.sendData(rowId);
        }
      };
      DataProcessor.prototype.markRow = function (id, state, mode) {
        var str = "";
        var invalid = this.is_invalid(id);
        if (invalid) {
          str = this.styles[invalid];
          state = true;
        }
        if (this.callEvent("onRowMark", [id, state, mode, invalid])) {
          // default logic
          str = this.styles[state ? mode : "clear"] + str;
          this.$gantt[this._methods[0]](id, str);
          if (invalid && invalid.details) {
            str += this.styles[invalid + "_cell"];
            for (var i = 0; i < invalid.details.length; i++) {
              if (invalid.details[i]) {
                this.$gantt[this._methods[1]](id, i, str);
              }
            }
          }
        }
      };
      DataProcessor.prototype.getActionByState = function (state) {
        if (state === "inserted") {
          return "create";
        }
        if (state === "updated") {
          return "update";
        }
        if (state === "deleted") {
          return "delete";
        }
        // reorder
        return "update";
      };
      DataProcessor.prototype.getState = function (id) {
        return this.$gantt.getUserData(id, this.action_param);
      };
      DataProcessor.prototype.is_invalid = function (id) {
        return this._invalid[id];
      };
      DataProcessor.prototype.set_invalid = function (id, mode, details) {
        if (details) {
          mode = {
            value: mode,
            details: details,
            toString: function () {
              return this.value.toString();
            }
          };
        }
        this._invalid[id] = mode;
      };
      /**
       * @desc: check mandatory fields and varify values of cells, initiate update (if specified)
       * @param: rowId - id of row to set update-status for
       * @type: public
       */
      // tslint:disable-next-line
      DataProcessor.prototype.checkBeforeUpdate = function (rowId) {
        return true;
      };
      /**
       * @desc: send row(s) values to server
       * @param: rowId - id of row which data to send. If not specified, then all "updated" rows will be send
       * @type: public
       */
      DataProcessor.prototype.sendData = function (rowId) {
        if (this._waitMode && (this.$gantt.mytype === "tree" || this.$gantt._h2)) {
          return;
        }
        if (this.$gantt.editStop) {
          this.$gantt.editStop();
        }
        if (typeof rowId === "undefined" || this._tSend) {
          return this.sendAllData();
        }
        if (this._in_progress[rowId]) {
          return false;
        }
        this.messages = [];
        if (!this.checkBeforeUpdate(rowId) && this.callEvent("onValidationError", [rowId, this.messages])) {
          return false; // ??? unreachable code, drop it?
        }
        this._beforeSendData(this._getRowData(rowId), rowId);
      };
      DataProcessor.prototype._beforeSendData = function (data, rowId) {
        if (!this.callEvent("onBeforeUpdate", [rowId, this.getState(rowId), data])) {
          return false;
        }
        this._sendData(data, rowId);
      };
      DataProcessor.prototype.serialize = function (data, id) {
        if (this._serializeAsJson) {
          return this._serializeAsJSON(data);
        }
        if (typeof data === "string") {
          return data;
        }
        if (typeof id !== "undefined") {
          return this.serialize_one(data, "");
        }
        else {
          var stack = [];
          var keys = [];
          for (var key in data) {
            if (data.hasOwnProperty(key)) {
              stack.push(this.serialize_one(data[key], key + this._postDelim));
              keys.push(key);
            }
          }
          stack.push("ids=" + this.escape(keys.join(",")));
          if (this.$gantt.security_key) {
            stack.push("dhx_security=" + this.$gantt.security_key);
          }
          return stack.join("&");
        }
      };
      DataProcessor.prototype._serializeAsJSON = function (data) {
        if (typeof data === "string") {
          return data;
        }
        var copy = utils.copy(data);
        if (this._tMode === "REST-JSON") {
          delete copy.id;
          delete copy[this.action_param];
        }
        return JSON.stringify(copy);
      };
      DataProcessor.prototype.serialize_one = function (data, pref) {
        if (typeof data === "string") {
          return data;
        }
        var stack = [];
        var serialized = "";
        for (var key in data)
          if (data.hasOwnProperty(key)) {
            if ((key === "id" ||
              key == this.action_param) && // tslint:disable-line
              this._tMode === "REST") {
              continue;
            }
            if (typeof data[key] === "string" || typeof data[key] === "number") {
              serialized = data[key];
            }
            else {
              serialized = JSON.stringify(data[key]);
            }
            stack.push(this.escape((pref || "") + key) + "=" + this.escape(serialized));
          }
        return stack.join("&");
      };
      DataProcessor.prototype._applyPayload = function (url) {
        var ajax = this.$gantt.ajax;
        if (this._payload) {
          for (var key in this._payload) {
            url = url + ajax.urlSeparator(url) + this.escape(key) + "=" + this.escape(this._payload[key]);
          }
        }
        return url;
      };
      DataProcessor.prototype._sendData = function (dataToSend, rowId) {
        var _this = this;
        if (!dataToSend) {
          return; // nothing to send
        }
        if (!this.callEvent("onBeforeDataSending", rowId ? [rowId, this.getState(rowId), dataToSend] : [null, null, dataToSend])) {
          return false;
        }
        if (rowId) {
          this._in_progress[rowId] = (new Date()).valueOf();
        }
        var ajax = this.$gantt.ajax;
        if (this._tMode === "CUSTOM") {
          var taskState_1 = this.getState(rowId);
          var taskAction = this.getActionByState(taskState_1);
          var ganttMode = this.getGanttMode();
          var _onResolvedCreateUpdate = function (tag) {
            var action = taskState_1 || "updated";
            var sid = rowId;
            var tid = rowId;
            if (tag) {
              action = tag.action || taskState_1;
              sid = tag.sid || sid;
              tid = tag.id || tag.tid || tid;
            }
            _this.afterUpdateCallback(sid, tid, action, tag);
          };
          var actionPromise = void 0;
          if (this._router instanceof Function) {
            actionPromise = this._router(ganttMode, taskAction, dataToSend, rowId);
          }
          else if (this._router[ganttMode] instanceof Function) {
            actionPromise = this._router[ganttMode](taskAction, dataToSend, rowId);
          }
          else {
            switch (taskState_1) {
              case "inserted":
                actionPromise = this._router[ganttMode].create(dataToSend);
                break;
              case "deleted":
                actionPromise = this._router[ganttMode].delete(rowId);
                break;
              default:
                actionPromise = this._router[ganttMode].update(dataToSend, rowId);
                break;
            }
          }
          if (actionPromise) {
            // neither promise nor {tid: newId} response object
            if (!actionPromise.then &&
              (actionPromise.id === undefined && actionPromise.tid === undefined)) {
              throw new Error("Incorrect router return value. A Promise or a response object is expected");
            }
            if (actionPromise.then) {
              actionPromise.then(_onResolvedCreateUpdate);
            }
            else {
              // custom method may return a response object in case of sync action
              _onResolvedCreateUpdate(actionPromise);
            }
          }
          else {
            _onResolvedCreateUpdate(null);
          }
          return;
        }
        var queryParams;
        queryParams = {
          callback: function (xml) {
            var ids = [];
            if (rowId) {
              ids.push(rowId);
            }
            else if (dataToSend) {
              for (var key in dataToSend) {
                ids.push(key);
              }
            }
            return _this.afterUpdate(_this, xml, ids);
          },
          headers: this._headers
        };
        var urlParams = this.serverProcessor + (this._user ? (ajax.urlSeparator(this.serverProcessor) + ["dhx_user=" + this._user, "dhx_version=" + this.$gantt.getUserData(0, "version")].join("&")) : "");
        var url = this._applyPayload(urlParams);
        var data;
        switch (this._tMode) {
          case "GET":
            queryParams.url = url + ajax.urlSeparator(url) + this.serialize(dataToSend, rowId);
            queryParams.method = "GET";
            break;
          case "POST":
            queryParams.url = url;
            queryParams.method = "POST";
            queryParams.data = this.serialize(dataToSend, rowId);
            break;
          case "JSON":
            data = {};
            for (var key in dataToSend) {
              if (key === this.action_param || key === "id" || key === "gr_id") {
                continue;
              }
              data[key] = dataToSend[key];
            }
            queryParams.url = url;
            queryParams.method = "POST";
            queryParams.data = JSON.stringify({
              id: rowId,
              action: dataToSend[this.action_param],
              data: data
            });
            break;
          case "REST":
          case "REST-JSON":
            url = urlParams.replace(/(&|\?)editing=true/, "");
            data = "";
            switch (this.getState(rowId)) {
              case "inserted":
                queryParams.method = "POST";
                queryParams.data = this.serialize(dataToSend, rowId);
                break;
              case "deleted":
                queryParams.method = "DELETE";
                url = url + (url.slice(-1) === "/" ? "" : "/") + rowId;
                break;
              default:
                queryParams.method = "PUT";
                queryParams.data = this.serialize(dataToSend, rowId);
                url = url + (url.slice(-1) === "/" ? "" : "/") + rowId;
                break;
            }
            queryParams.url = this._applyPayload(url);
            break;
        }
        this._waitMode++;
        return ajax.query(queryParams);
      };
      DataProcessor.prototype._forEachUpdatedRow = function (code) {
        var updatedRows = this.updatedRows.slice();
        for (var i = 0; i < updatedRows.length; i++) {
          var rowId = updatedRows[i];
          if (this.$gantt.getUserData(rowId, this.action_param)) {
            code.call(this, rowId);
          }
        }
      };
      DataProcessor.prototype.sendAllData = function () {
        if (!this.updatedRows.length) {
          return;
        }
        this.messages = [];
        var valid = true;
        this._forEachUpdatedRow(function (rowId) {
          valid = valid && this.checkBeforeUpdate(rowId); // ??? checkBeforeUpdate() always is true
        });
        if (!valid && !this.callEvent("onValidationError", ["", this.messages])) {
          return false;
        }
        if (this._tSend) {
          this._sendData(this._getAllData());
        }
        else {
          var stop_1 = false;
          // this.updatedRows can be spliced from onBeforeUpdate via dp.setUpdated false
          // use an iterator instead of for(var i = 0; i < this.updatedRows; i++) then
          this._forEachUpdatedRow(function (rowId) {
            if (stop_1) {
              return;
            }
            if (!this._in_progress[rowId]) {
              if (this.is_invalid(rowId)) {
                return;
              }
              this._beforeSendData(this._getRowData(rowId), rowId);
              if (this._waitMode && (this.$gantt.mytype === "tree" || this.$gantt._h2)) {
                stop_1 = true; // block send all for tree
              }
            }
          });
        }
      };
      DataProcessor.prototype._getAllData = function () {
        var out = {};
        var hasOne = false;
        this._forEachUpdatedRow(function (id) {
          if (this._in_progress[id] || this.is_invalid(id)) {
            return;
          }
          var row = this._getRowData(id);
          if (!this.callEvent("onBeforeUpdate", [id, this.getState(id), row])) {
            return;
          }
          out[id] = row;
          hasOne = true;
          this._in_progress[id] = (new Date()).valueOf();
        });
        return hasOne ? out : null;
      };
      /**
       * @desc: specify column which value should be verified before sending to server
       * @param: ind - column index (0 based)
       * @param: verifFunction - function(object) which should verify cell value (if not specified, then value will be compared to empty string). Two arguments will be passed into it: value and column name
       * @type: public
       */
      DataProcessor.prototype.setVerificator = function (ind, verifFunction) {
        this.mandatoryFields[ind] = verifFunction || (function (value) { return (value !== ""); });
      };
      /**
       * @desc: remove column from list of those which should be verified
       * @param: ind - column Index (0 based)
       * @type: public
       */
      DataProcessor.prototype.clearVerificator = function (ind) {
        this.mandatoryFields[ind] = false;
      };
      DataProcessor.prototype.findRow = function (pattern) {
        var i = 0;
        for (i = 0; i < this.updatedRows.length; i++) {
          if (pattern == this.updatedRows[i]) { // tslint:disable-line
            break;
          }
        }
        return i;
      };
      /**
       * @desc: define custom actions
       * @param: name - name of action, same as value of action attribute
       * @param: handler - custom function, which receives a XMl response content for action
       * @type: private
       */
      DataProcessor.prototype.defineAction = function (name, handler) {
        if (!this._uActions) {
          this._uActions = {};
        }
        this._uActions[name] = handler;
      };
      /**
       * @desc: used in combination with setOnBeforeUpdateHandler to create custom client-server transport system
       * @param: sid - id of item before update
       * @param: tid - id of item after up0ate
       * @param: action - action name
       * @type: public
       * @topic: 0
       */
      DataProcessor.prototype.afterUpdateCallback = function (sid, tid, action, btag) {
        if (!this.$gantt) {
          // destructor has been called before the callback
          return;
        }
        var marker = sid;
        var correct = (action !== "error" && action !== "invalid");
        if (!correct) {
          this.set_invalid(sid, action);
        }
        if ((this._uActions) && (this._uActions[action]) && (!this._uActions[action](btag))) {
          return (delete this._in_progress[marker]);
        }
        if (this._in_progress[marker] !== "wait") {
          this.setUpdated(sid, false);
        }
        var originalSid = sid;
        switch (action) {
          case "inserted":
          case "insert":
            if (tid != sid) { // tslint:disable-line
              this.setUpdated(sid, false);
              this.$gantt[this._methods[2]](sid, tid);
              sid = tid;
            }
            break;
          case "delete":
          case "deleted":
            this.$gantt.setUserData(sid, this.action_param, "true_deleted");
            this.$gantt[this._methods[3]](sid);
            delete this._in_progress[marker];
            return this.callEvent("onAfterUpdate", [sid, action, tid, btag]);
        }
        if (this._in_progress[marker] !== "wait") {
          if (correct) {
            this.$gantt.setUserData(sid, this.action_param, "");
          }
          delete this._in_progress[marker];
        }
        else {
          delete this._in_progress[marker];
          this.setUpdated(tid, true, this.$gantt.getUserData(sid, this.action_param));
        }
        this.callEvent("onAfterUpdate", [originalSid, action, tid, btag]);
      };
      /**
       * @desc: response from server
       * @param: xml - XMLLoader object with response XML
       * @type: private
       */
      DataProcessor.prototype.afterUpdate = function (that, xml, id) {
        var _xml;
        if (arguments.length === 3) {
          _xml = arguments[1];
        }
        else {
          // old dataprocessor
          _xml = arguments[4];
        }
        var mode = this.getGanttMode();
        var reqUrl = _xml.filePath || _xml.url;
        if (this._tMode !== "REST" && this._tMode !== "REST-JSON") {
          if (reqUrl.indexOf("gantt_mode=links") !== -1) {
            mode = "link";
          }
          else {
            mode = "task";
          }
        }
        else {
          if (reqUrl.indexOf("/link") > reqUrl.indexOf("/task")) {
            mode = "link";
          }
          else {
            mode = "task";
          }
        }
        this.setGanttMode(mode);
        var ajax = this.$gantt.ajax;
        // try to use json first
        if (window.JSON) {
          var tag = void 0;
          try {
            tag = JSON.parse(xml.xmlDoc.responseText);
          }
          catch (e) {
            // empty response also can be processed by json handler
            if (!xml.xmlDoc.responseText.length) {
              tag = {};
            }
          }
          if (tag) {
            var action = tag.action || this.getState(id) || "updated";
            var sid = tag.sid || id[0];
            var tid = tag.tid || id[0];
            that.afterUpdateCallback(sid, tid, action, tag);
            that.finalizeUpdate();
            this.setGanttMode(mode);
            return;
          }
        }
        // xml response
        var top = ajax.xmltop("data", xml.xmlDoc); // fix incorrect content type in IE
        if (!top) {
          return this.cleanUpdate(id);
        }
        var atag = ajax.xpath("//data/action", top);
        if (!atag.length) {
          return this.cleanUpdate(id);
        }
        for (var i = 0; i < atag.length; i++) {
          var btag = atag[i];
          var action = btag.getAttribute("type");
          var sid = btag.getAttribute("sid");
          var tid = btag.getAttribute("tid");
          that.afterUpdateCallback(sid, tid, action, btag);
        }
        that.finalizeUpdate();
      };
      DataProcessor.prototype.cleanUpdate = function (id) {
        if (id) {
          for (var i = 0; i < id.length; i++) {
            delete this._in_progress[id[i]];
          }
        }
      };
      DataProcessor.prototype.finalizeUpdate = function () {
        if (this._waitMode) {
          this._waitMode--;
        }
        if ((this.$gantt.mytype === "tree" || this.$gantt._h2) && this.updatedRows.length) {
          this.sendData();
        }
        this.callEvent("onAfterUpdateFinish", []);
        if (!this.updatedRows.length) {
          this.callEvent("onFullSync", []);
        }
      };
      /**
       * @desc: initializes data-processor
       * @param: anObj - dhtmlxGrid object to attach this data-processor to
       * @type: public
       */
      DataProcessor.prototype.init = function (anObj) {
        if (this._initialized) {
          return;
        }
        this.$gantt = anObj;
        if (this.$gantt._dp_init) {
          this.$gantt._dp_init(this);
        }
        this._setDefaultTransactionMode();
        this.styles = {
          updated: "gantt_updated",
          order: "gantt_updated",
          inserted: "gantt_inserted",
          deleted: "gantt_deleted",
          invalid: "gantt_invalid",
          error: "gantt_error",
          clear: ""
        };
        this._methods = ["_row_style", "setCellTextStyle", "_change_id", "_delete_task"];
        extend_gantt_1.default(this.$gantt, this);
        var dataProcessorEvents = new data_processor_events_1.default(this.$gantt, this);
        dataProcessorEvents.attach();
        this.attachEvent("onDestroy", function () {
          delete this.setGanttMode;
          delete this._getRowData;
          delete this.$gantt._dp;
          delete this.$gantt._change_id;
          delete this.$gantt._row_style;
          delete this.$gantt._delete_task;
          delete this.$gantt._sendTaskOrder;
          delete this.$gantt;
          dataProcessorEvents.detach();
        });
        this.$gantt.callEvent("onDataProcessorReady", [this]);
        this._initialized = true;
      };
      DataProcessor.prototype._setDefaultTransactionMode = function () {
        if (this.serverProcessor) {
          this.setTransactionMode("POST", true);
          this.serverProcessor += (this.serverProcessor.indexOf("?") !== -1 ? "&" : "?") + "editing=true";
          this._serverProcessor = this.serverProcessor;
        }
      };
      DataProcessor.prototype.setOnAfterUpdate = function (handler) {
        this.attachEvent("onAfterUpdate", handler);
      };
      DataProcessor.prototype.enableDebug = function (mode) { }; // tslint:disable-line
      DataProcessor.prototype.setOnBeforeUpdateHandler = function (handler) {
        this.attachEvent("onBeforeDataSending", handler);
      };
      /* starts autoupdate mode
          @param interval time interval for sending update requests
      */
      DataProcessor.prototype.setAutoUpdate = function (interval, user) {
        var _this = this;
        interval = interval || 2000;
        this._user = user || (new Date()).valueOf();
        this._needUpdate = false;
        // this._loader = null;
        this._updateBusy = false;
        this.attachEvent("onAfterUpdate", this.afterAutoUpdate); // arguments sid, action, tid, xml_node;
        this.attachEvent("onFullSync", this.fullSync);
        window.setInterval(function () {
          _this.loadUpdate();
        }, interval);
      };
      /* process updating request answer
          if status == collision version is depricated
          set flag for autoupdating immidiatly
      */
      DataProcessor.prototype.afterAutoUpdate = function (sid, action, tid, xml_node) {
        if (action === "collision") {
          this._needUpdate = true;
          return false;
        }
        else {
          return true;
        }
      };
      /* callback function for onFillSync event
          call update function if it's need
      */
      DataProcessor.prototype.fullSync = function () {
        if (this._needUpdate) {
          this._needUpdate = false;
          this.loadUpdate();
        }
        return true;
      };
      /* sends query to the server and call callback function
      */
      DataProcessor.prototype.getUpdates = function (url, callback) {
        var ajax = this.$gantt.ajax;
        if (this._updateBusy) {
          return false;
        }
        else {
          this._updateBusy = true;
        }
        // this._loader = this._loader || new dtmlXMLLoaderObject(true);
        // this._loader.async=true;
        // this._loader.waitCall=callback;
        // this._loader.loadXML(url);
        ajax.get(url, callback);
      };
      // I didn't found some use of _v and _a functions
      /* returns xml node value
          @param node
              xml node
      */
      DataProcessor.prototype._v = function (node) {
        if (node.firstChild) {
          return node.firstChild.nodeValue;
        }
        return "";
      };
      /* returns values array of xml nodes array
          @param arr
              array of xml nodes
      */
      DataProcessor.prototype._a = function (arr) {
        var res = [];
        for (var i = 0; i < arr.length; i++) {
          res[i] = this._v(arr[i]);
        }
        return res;
      };
      /* loads updates and processes them
      */
      DataProcessor.prototype.loadUpdate = function () {
        var _this = this;
        var ajax = this.$gantt.ajax;
        var version = this.$gantt.getUserData(0, "version");
        var url = this.serverProcessor + ajax.urlSeparator(this.serverProcessor) + ["dhx_user=" + this._user, "dhx_version=" + version].join("&");
        url = url.replace("editing=true&", "");
        this.getUpdates(url, function (xml) {
          var vers = ajax.xpath("//userdata", xml);
          _this.obj.setUserData(0, "version", _this._v(vers[0]));
          var upds = ajax.xpath("//update", xml);
          if (upds.length) {
            _this._silent_mode = true;
            for (var i = 0; i < upds.length; i++) {
              var status_1 = upds[i].getAttribute("status");
              var id = upds[i].getAttribute("id");
              var parent_1 = upds[i].getAttribute("parent");
              switch (status_1) {
                case "inserted":
                  _this.callEvent("insertCallback", [upds[i], id, parent_1]);
                  break;
                case "updated":
                  _this.callEvent("updateCallback", [upds[i], id, parent_1]);
                  break;
                case "deleted":
                  _this.callEvent("deleteCallback", [upds[i], id, parent_1]);
                  break;
              }
            }
            _this._silent_mode = false;
          }
          _this._updateBusy = false;
        });
      };
      DataProcessor.prototype.destructor = function () {
        this.callEvent("onDestroy", []);
        this.detachAllEvents();
        this.updatedRows = [];
        this._in_progress = {}; // ?
        this._invalid = {};
        this._headers = null;
        this._payload = null;
        delete this._initialized;
      };
      DataProcessor.prototype.setGanttMode = function (mode) {
        if (mode === "tasks") {
          mode = "task";
        }
        else if (mode === "links") {
          mode = "link";
        }
        var modes = this.modes || {};
        var ganttMode = this.getGanttMode();
        if (ganttMode) {
          modes[ganttMode] = {
            _in_progress: this._in_progress,
            _invalid: this._invalid,
            updatedRows: this.updatedRows
          };
        }
        var newState = modes[mode];
        if (!newState) {
          newState = modes[mode] = {
            _in_progress: {},
            _invalid: {},
            updatedRows: []
          };
        }
        this._in_progress = newState._in_progress;
        this._invalid = newState._invalid;
        this.updatedRows = newState.updatedRows;
        this.modes = modes;
        this._ganttMode = mode;
      };
      DataProcessor.prototype.getGanttMode = function () {
        return this._ganttMode;
      };
      DataProcessor.prototype._getRowData = function (id) {
        var task;
        if (this.getGanttMode() === "task") {
          task = this.$gantt.isTaskExists(id) ? this.$gantt.getTask(id) : { id: id };
        }
        else {
          task = this.$gantt.isLinkExists(id) ? this.$gantt.getLink(id) : { id: id };
        }
        task = this.$gantt.copy(task);
        var data = {};
        for (var key in task) {
          if (key.substr(0, 1) === "$") {
            continue;
          }
          var value = task[key];
          if (helpers.isDate(value)) {
            data[key] = this.$gantt.templates.xml_format !== this.$gantt.templates.format_date ? this.$gantt.templates.xml_format(value) : this.$gantt.templates.format_date(value);
          }
          else if (value === null) {
            data[key] = "";
          }
          else {
            data[key] = value;
          }
        }
        var taskTiming = this.$gantt._get_task_timing_mode(task);
        if (taskTiming.$no_start) {
          task.start_date = "";
          task.duration = "";
        }
        if (taskTiming.$no_end) {
          task.end_date = "";
          task.duration = "";
        }
        data[this.action_param] = this.$gantt.getUserData(id, this.action_param);
        return data;
      };
      DataProcessor.prototype._isFetchResult = function (result) {
        return result.body instanceof ReadableStream;
      };
      DataProcessor.prototype.setSerializeAsJSON = function (flag) {
        this._serializeAsJson = flag;
      };
      return DataProcessor;
    }());
    return DataProcessor;


    /***/
  }

  dataProcessorEvents() {


    // Object.defineProperty(exports, "__esModule", { value: true });
    var helpers = this.utilsService.helpers;
    var DataProcessorEvents = /** @class */ (function () {
      function DataProcessorEvents(gantt, dp) {
        this.$gantt = gantt;
        this.$dp = dp;
        this._dataProcessorHandlers = [];
      }
      DataProcessorEvents.prototype.attach = function () {
        var dp = this.$dp;
        var gantt = this.$gantt;
        var treeHelper = this.utilsService.task_tree_helpers();
        var cascadeDelete = {};
        function clientSideDelete(id) {
          var updated = dp.updatedRows.slice();
          var clientOnly = false;
          for (var i = 0; i < updated.length && !dp._in_progress[id]; i++) {
            if (updated[i] === id) {
              if (gantt.getUserData(id, "!nativeeditor_status") === "inserted") {
                clientOnly = true;
              }
              dp.setUpdated(id, false);
            }
          }
          return clientOnly;
        }
        function getTaskLinks(task) {
          var _links = [];
          if (task.$source) {
            _links = _links.concat(task.$source);
          }
          if (task.$target) {
            _links = _links.concat(task.$target);
          }
          return _links;
        }
        this._dataProcessorHandlers.push(gantt.attachEvent("onAfterTaskAdd", function (id, item) {
          if (gantt.isTaskExists(id)) {
            dp.setGanttMode("tasks");
            dp.setUpdated(id, true, "inserted");
          }
        }));
        this._dataProcessorHandlers.push(gantt.attachEvent("onAfterTaskUpdate", function (id, item) {
          if (gantt.isTaskExists(id)) {
            dp.setGanttMode("tasks");
            dp.setUpdated(id, true);
            // gantt can be destroyed/reinitialized after dp.setUpdated
            if (gantt._sendTaskOrder) {
              gantt._sendTaskOrder(id, item);
            }
          }
        }));
        this._dataProcessorHandlers.push(gantt.attachEvent("onBeforeTaskDelete", function (id, item) {
          if (!gantt.config.cascade_delete) {
            return true;
          }
          cascadeDelete[id] = {
            tasks: treeHelper.getSubtreeTasks(gantt, id),
            links: treeHelper.getSubtreeLinks(gantt, id)
          };
          return true;
        }));
        this._dataProcessorHandlers.push(gantt.attachEvent("onAfterTaskDelete", function (id, item) {
          dp.setGanttMode("tasks");
          // not send delete request if item is not inserted into the db - just remove it from the client
          var needDbDelete = !clientSideDelete(id);
          if (!needDbDelete) {
            return;
          }
          if (gantt.config.cascade_delete && cascadeDelete[id]) {
            var dpMode = dp.updateMode;
            dp.setUpdateMode("off");
            var cascade = cascadeDelete[id];
            for (var i in cascade.tasks) {
              if (!clientSideDelete(i)) {
                dp.setUpdated(i, true, "deleted");
              }
            }
            dp.setGanttMode("links");
            for (var i in cascade.links) {
              if (!clientSideDelete(i)) {
                dp.setUpdated(i, true, "deleted");
              }
            }
            cascadeDelete[id] = null;
            if (dpMode !== "off") {
              dp.sendAllData();
            }
            dp.setGanttMode("tasks");
            dp.setUpdateMode(dpMode);
          }
          dp.setUpdated(id, true, "deleted");
          if (dp.updateMode !== "off" && !dp._tSend) {
            dp.sendAllData();
          }
        }));
        this._dataProcessorHandlers.push(gantt.attachEvent("onAfterLinkUpdate", function (id, item) {
          if (gantt.isLinkExists(id)) {
            dp.setGanttMode("links");
            dp.setUpdated(id, true);
          }
        }));
        this._dataProcessorHandlers.push(gantt.attachEvent("onAfterLinkAdd", function (id, item) {
          if (gantt.isLinkExists(id)) {
            dp.setGanttMode("links");
            dp.setUpdated(id, true, "inserted");
          }
        }));
        this._dataProcessorHandlers.push(gantt.attachEvent("onAfterLinkDelete", function (id, item) {
          dp.setGanttMode("links");
          var needDbDelete = !clientSideDelete(id);
          if (!needDbDelete) {
            return;
          }
          dp.setUpdated(id, true, "deleted");
        }));
        this._dataProcessorHandlers.push(gantt.attachEvent("onRowDragEnd", function (id, target) {
          gantt._sendTaskOrder(id, gantt.getTask(id));
        }));
        var tasks = null;
        var links = null;
        this._dataProcessorHandlers.push(gantt.attachEvent("onTaskIdChange", function (oldId, newId) {
          if (!dp._waitMode) {
            return;
          }
          var children = gantt.getChildren(newId);
          if (children.length) {
            tasks = tasks || {};
            for (var i = 0; i < children.length; i++) {
              var ch = this.getTask(children[i]);
              tasks[ch.id] = ch;
            }
          }
          var item = this.getTask(newId);
          var itemLinks = getTaskLinks(item);
          if (itemLinks.length) {
            links = links || {};
            for (var i = 0; i < itemLinks.length; i++) {
              var link = this.getLink(itemLinks[i]);
              links[link.id] = link;
            }
          }
        }));
        dp.attachEvent("onAfterUpdateFinish", function () {
          if (tasks || links) {
            gantt.batchUpdate(function () {
              for (var id in tasks) {
                gantt.updateTask(tasks[id].id);
              }
              for (var id in links) {
                gantt.updateLink(links[id].id);
              }
              tasks = null;
              links = null;
            });
            if (tasks) {
              gantt._dp.setGanttMode("tasks");
            }
            else {
              gantt._dp.setGanttMode("links");
            }
          }
        });
        dp.attachEvent("onBeforeDataSending", function () {
          if (this._tMode === "CUSTOM") {
            return true;
          }
          var url = this._serverProcessor;
          if (this._tMode === "REST-JSON" || this._tMode === "REST") {
            var mode = this._ganttMode;
            url = url.substring(0, url.indexOf("?") > -1 ? url.indexOf("?") : url.length);
            // editing=true&
            this.serverProcessor = url + (url.slice(-1) === "/" ? "" : "/") + mode;
          }
          else {
            var pluralizedMode = this._ganttMode + "s";
            this.serverProcessor = url + gantt.ajax.urlSeparator(url) + "gantt_mode=" + pluralizedMode;
          }
          return true;
        });
        dp.attachEvent("insertCallback", function insertCallback(upd, id, parent, mode) {
          var data = upd.data || gantt.xml._xmlNodeToJSON(upd.firstChild);
          var methods = {
            add: gantt.addTask,
            isExist: gantt.isTaskExists
          };
          if (mode === "links") {
            methods.add = gantt.addLink;
            methods.isExist = gantt.isLinkExists;
          }
          if (methods.isExist.call(gantt, id)) {
            return;
          }
          data.id = id;
          methods.add.call(gantt, data);
        });
        dp.attachEvent("updateCallback", function updateCallback(upd, id) {
          var data = upd.data || gantt.xml._xmlNodeToJSON(upd.firstChild);
          if (!gantt.isTaskExists(id)) {
            return;
          }
          var objData = gantt.getTask(id);
          for (var key in data) {
            var property = data[key];
            switch (key) {
              case "id":
                continue;
              case "start_date":
              case "end_date":
                property = gantt.templates.xml_date !== gantt.templates.parse_date ? gantt.templates.xml_date(property) : gantt.templates.parse_date(property);
                break;
              case "duration":
                objData.end_date = gantt.calculateEndDate({ start_date: objData.start_date, duration: property, task: objData });
                break;
            }
            objData[key] = property;
          }
          gantt.updateTask(id);
          gantt.refreshData();
        });
        dp.attachEvent("deleteCallback", function deleteCallback(upd, id, parent, mode) {
          var methods = {
            delete: gantt.deleteTask,
            isExist: gantt.isTaskExists
          };
          if (mode === "links") {
            methods.delete = gantt.deleteLink;
            methods.isExist = gantt.isLinkExists;
          }
          if (methods.isExist.call(gantt, id)) {
            methods.delete.call(gantt, id);
          }
        });
      };
      DataProcessorEvents.prototype.detach = function () {
        var _this = this;
        helpers.forEach(this._dataProcessorHandlers, function (e) {
          _this.$gantt.detachEvent(e);
        });
        this._dataProcessorHandlers = [];
      };
      return DataProcessorEvents;
    }());
    return { default : DataProcessorEvents};


    /***/
  }

  extendGantt() {

    // "use strict";

    // Object.defineProperty(exports, "__esModule", { value: true });
    function extendGantt(gantt, dp) {
      gantt.getUserData = function (id, name) {
        if (!this.userdata) {
          this.userdata = {};
        }
        if (this.userdata[id] && this.userdata[id][name]) {
          return this.userdata[id][name];
        }
        return "";
      };
      gantt.setUserData = function (id, name, value) {
        if (!this.userdata) {
          this.userdata = {};
        }
        if (!this.userdata[id]) {
          this.userdata[id] = {};
        }
        this.userdata[id][name] = value;
      };
      gantt._change_id = function (oldId, newId) {
        if (this._dp._ganttMode !== "task") {
          this.changeLinkId(oldId, newId);
        }
        else {
          this.changeTaskId(oldId, newId);
        }
      };
      gantt._row_style = function (rowId, classname) {
        if (this._dp._ganttMode !== "task") {
          return;
        }
        if (!gantt.isTaskExists(rowId)) {
          return;
        }
        var task = gantt.getTask(rowId);
        task.$dataprocessor_class = classname;
        gantt.refreshTask(rowId);
      };
      // fake method for dataprocessor
      gantt._delete_task = function (rowId, node) { }; // tslint:disable-line
      gantt._sendTaskOrder = function (id, item) {
        if (item.$drop_target) {
          this._dp.setGanttMode("task");
          this.getTask(id).target = item.$drop_target;
          this._dp.setUpdated(id, true, "order");
          delete this.getTask(id).$drop_target;
        }
      };
      gantt.setDp = function () {
        this._dp = dp;
      };
      gantt.setDp();
    }
    return { default : extendGantt };


    /***/
  }

  index() {

    var DataProcessor = this.dataProcessor();
    return {
      DEPRECATED_api: function (server) {
        return new (DataProcessor.DataProcessor)(server);
      },
      createDataProcessor: DataProcessor.createDataProcessor,
      getDataProcessorModes: DataProcessor.getAvailableModes
    };

    /***/
  }

}
