import { Injectable } from '@angular/core';
import { UtilsService } from '../../utils/utils.service';
import { RenderService } from '../ui/render/render.service';

@Injectable({
  providedIn: 'root'
})
export class PluginsService {

  constructor(private utilsService: UtilsService, private renderService: RenderService) { }

  autoTaskTypes() {

    return function (gantt) {
      function isEnabled() {
        return gantt.config.auto_types && // if enabled
          (gantt.getTaskType(gantt.config.types.project) == gantt.config.types.project);// and supported
      }

      function callIfEnabled(callback) {
        return function () {
          if (!isEnabled()) {
            return true;
          }
          return callback.apply(this, arguments);
        };
      }

      function updateParents(childId) {
        gantt.batchUpdate(function () {
          checkParent(childId);
        });
      }

      var delTaskParent;

      function checkParent(id) {
        setTaskType(id);
        var parent = gantt.getParent(id);

        if (parent != gantt.config.root_id) {
          checkParent(parent);
        }
      }

      function setTaskType(id) {
        id = id.id || id;
        var task = gantt.getTask(id);
        var targetType = getTaskTypeToUpdate(task);

        if (targetType !== false) {
          updateTaskType(task, targetType);
        }
      }

      function updateTaskType(task, targetType) {
        if (!gantt.getState().group_mode) {
          task.type = targetType;
          gantt.updateTask(task.id);
        }
      }

      function getTaskTypeToUpdate(task) {
        var allTypes = gantt.config.types;
        var hasChildren = gantt.hasChild(task.id);
        var taskType = gantt.getTaskType(task.type);

        if (hasChildren && taskType === allTypes.task) {
          return allTypes.project;
        }

        if (!hasChildren && taskType === allTypes.project) {
          return allTypes.task;
        }

        return false;
      }

      var isParsingDone = true;

      gantt.attachEvent("onParse", callIfEnabled(function () {
        isParsingDone = false;

        gantt.batchUpdate(function () {
          gantt.eachTask(function (task) {
            var targetType = getTaskTypeToUpdate(task);
            if (targetType !== false) {
              updateTaskType(task, targetType);
            }
          });
        });

        isParsingDone = true;
      }));

      gantt.attachEvent("onAfterTaskAdd", callIfEnabled(function (id) {
        if (isParsingDone) {
          updateParents(id);
        }
      }));

      gantt.attachEvent("onAfterTaskUpdate", callIfEnabled(function (id) {
        if (isParsingDone) {
          updateParents(id);
        }
      }));

      function updateAfterRemoveChild(id) {
        if (id != gantt.config.root_id && gantt.isTaskExists(id)) {
          updateParents(id);
        }
      }

      gantt.attachEvent("onBeforeTaskDelete", callIfEnabled(function (id, task) {
        delTaskParent = gantt.getParent(id);
        return true;
      }));

      gantt.attachEvent("onAfterTaskDelete", callIfEnabled(function (id, task) {
        updateAfterRemoveChild(delTaskParent);
      }));


      var originalRowDndParent;

      gantt.attachEvent("onRowDragStart", callIfEnabled(function (id, target, e) {
        originalRowDndParent = gantt.getParent(id);
        return true;
      }));

      gantt.attachEvent("onRowDragEnd", callIfEnabled(function (id, target) {
        updateAfterRemoveChild(originalRowDndParent);
        updateParents(id);
      }));

      var originalMoveTaskParent;

      gantt.attachEvent("onBeforeTaskMove", callIfEnabled(function (sid, parent, tindex) {
        originalMoveTaskParent = gantt.getParent(sid);
        return true;
      }));

      gantt.attachEvent("onAfterTaskMove", callIfEnabled(function (id, parent, tindex) {
        if (document.querySelector(".gantt_drag_marker")) {
          // vertical dnd in progress
          return;
        }
        updateAfterRemoveChild(originalMoveTaskParent);
        updateParents(id);
      }));
    };

    /***/
  }

  autoscroll() {

    var domHelpers = this.utilsService.domHelpers();

    return function (gantt) {

      var scrollRange = 50,
        scrollStep = 30,
        scrollDelay = 10,
        scrollSpeed = 50;

      var interval = null,
        isMove = false,
        delayTimeout = null,
        startPos: any = {
          started: false
        },
        eventPos: any = {};


      function isDisplayed(element) {
        return element &&
          domHelpers.isChildOf(element, gantt.$root) &&
          element.offsetHeight;
      }

      function getAutoscrollContainer() {
        var element;
        if (isDisplayed(gantt.$task)) {
          element = gantt.$task;
        } else if (isDisplayed(gantt.$grid)) {
          element = gantt.$grid;
        } else {
          element = gantt.$root;
        }

        return element;
      }

      function isScrollState() {
        var dragMarker = !!document.querySelector(".gantt_drag_marker");
        var isResize = !!document.querySelector(".gantt_drag_marker.gantt_grid_resize_area");
        var isLink = !!document.querySelector(".gantt_link_direction");
        var state = gantt.getState();
        var isClickDrag = state.autoscroll;
        isMove = dragMarker && !isResize && !isLink;

        return !((!state.drag_mode && !dragMarker) || isResize) || isClickDrag;
      }

      function defineDelayTimeout(state) {
        if (delayTimeout) {
          clearTimeout(delayTimeout);
          delayTimeout = null;
        }
        if (state) {
          var speed = gantt.config.autoscroll_speed;
          if (speed && speed < 10) // limit speed value to 10
            speed = 10;

          delayTimeout = setTimeout(function () {
            interval = setInterval(tick, speed || scrollSpeed);
          }, gantt.config.autoscroll_delay || scrollDelay);
        }
      }

      function defineScrollInterval(state) {
        if (state) {
          defineDelayTimeout(true);
          if (!startPos.started) {
            startPos.x = eventPos.x;
            startPos.y = eventPos.y;
            startPos.started = true;
          }
        } else {
          if (interval) {
            clearInterval(interval);
            interval = null;
          }
          defineDelayTimeout(false);
          startPos.started = false;
        }
      }

      function autoscrollInterval(event) {

        var isScroll = isScrollState();

        if ((interval || delayTimeout) && !isScroll) {
          defineScrollInterval(false);
        }

        if (!gantt.config.autoscroll || !isScroll) {
          return false;
        }

        eventPos = {
          x: event.clientX,
          y: event.clientY
        };

        if (!interval && isScroll) {
          defineScrollInterval(true);
        }
      }

      function tick() {

        if (!isScrollState()) {
          defineScrollInterval(false);
          return false;
        }

        var box = domHelpers.getNodePosition(getAutoscrollContainer());
        var posX = eventPos.x - box.x;
        var posY = eventPos.y - box.y;

        var scrollLeft = isMove ? 0 : need_scroll(posX, box.width, startPos.x - box.x);
        var scrollTop = need_scroll(posY, box.height, startPos.y - box.y);

        var scrollState = gantt.getScrollState();

        var currentScrollTop = scrollState.y,
          scrollOuterHeight = scrollState.inner_height,
          scrollInnerHeight = scrollState.height,
          currentScrollLeft = scrollState.x,
          scrollOuterWidth = scrollState.inner_width,
          scrollInnerWidth = scrollState.width;

        // do scrolling only if we have scrollable area to do so
        if (scrollTop && !scrollOuterHeight) {
          scrollTop = 0;
        } else if (scrollTop < 0 && !currentScrollTop) {
          scrollTop = 0;
        } else if (scrollTop > 0 && currentScrollTop + scrollOuterHeight >= scrollInnerHeight + 2) {
          scrollTop = 0;
        }

        if (scrollLeft && !scrollOuterWidth) {
          scrollLeft = 0;
        } else if (scrollLeft < 0 && !currentScrollLeft) {
          scrollLeft = 0;
        } else if (scrollLeft > 0 && currentScrollLeft + scrollOuterWidth >= scrollInnerWidth) {
          scrollLeft = 0;
        }

        var step = gantt.config.autoscroll_step;

        if (step && step < 2) // limit step value to 2
          step = 2;

        scrollLeft = scrollLeft * (step || scrollStep);
        scrollTop = scrollTop * (step || scrollStep);

        if (scrollLeft || scrollTop) {
          scroll(scrollLeft, scrollTop);
        }
      }

      function need_scroll(pos, boxSize, startCoord) {
        if ((pos - scrollRange < 0) && (pos < startCoord))
          return -1;
        else if ((pos > boxSize - scrollRange) && (pos > startCoord))
          return 1;
        return 0;
      }

      function scroll(left, top) {
        var scrollState = gantt.getScrollState();

        var scrollLeft = null,
          scrollTop = null;

        if (left) {
          scrollLeft = scrollState.x + left;
          scrollLeft = Math.min(scrollState.width, scrollLeft);
          scrollLeft = Math.max(0, scrollLeft);
        }

        if (top) {
          scrollTop = scrollState.y + top;
          scrollTop = Math.min(scrollState.height, scrollTop);
          scrollTop = Math.max(0, scrollTop);
        }

        gantt.scrollTo(scrollLeft, scrollTop);
      }

      gantt.attachEvent("onGanttReady", function () {
        gantt.eventRemove(document.body, "mousemove", autoscrollInterval);
        gantt.event(document.body, "mousemove", autoscrollInterval);
      });

    };

    /***/
  }

  batch_update() {

    function createMethod(gantt) {
      var methods = {};
      var isActive = false;
      function disableMethod(methodName, dummyMethod) {
        dummyMethod = typeof dummyMethod == "function" ? dummyMethod : function () { };

        if (!methods[methodName]) {
          methods[methodName] = this[methodName];
          this[methodName] = dummyMethod;
        }
      }
      function restoreMethod(methodName) {
        if (methods[methodName]) {
          this[methodName] = methods[methodName];
          methods[methodName] = null;
        }
      }
      function disableMethods(methodsHash) {
        for (var i in methodsHash) {
          disableMethod.call(this, i, methodsHash[i]);
        }
      }
      function restoreMethods() {
        for (var i in methods) {
          restoreMethod.call(this, i);
        }
      }

      function batchUpdatePayload(callback) {
        try {
          callback();
        } catch (e) {
          window.console.error(e);
        }
      }

      var state = gantt.$services.getService("state");
      state.registerProvider("batchUpdate", function () {
        return {
          batch_update: isActive
        };
      }, true);

      return function batchUpdate(callback, noRedraw) {
        if (isActive) {
          // batch mode is already active
          batchUpdatePayload(callback);
          return;
        }

        var call_dp = (this._dp && this._dp.updateMode != "off");
        var dp_mode;
        if (call_dp) {
          dp_mode = this._dp.updateMode;
          this._dp.setUpdateMode("off");
        }

        // temporary disable some methods while updating multiple tasks
        var resetProjects = {};
        var methods = {
          "render": true,
          "refreshData": true,
          "refreshTask": true,
          "refreshLink": true,
          "resetProjectDates": function (task) {
            resetProjects[task.id] = task;
          }
        };

        disableMethods.call(this, methods);

        isActive = true;
        this.callEvent("onBeforeBatchUpdate", []);

        batchUpdatePayload(callback);

        this.callEvent("onAfterBatchUpdate", []);

        restoreMethods.call(this);

        // do required updates after changes applied
        for (var i in resetProjects) {
          this.resetProjectDates(resetProjects[i]);
        }

        isActive = false;

        if (!noRedraw) {
          this.render();
        }

        if (call_dp) {
          this._dp.setUpdateMode(dp_mode);
          this._dp.setGanttMode("task");
          this._dp.sendData();
          this._dp.setGanttMode("link");
          this._dp.sendData();
        }
      };



    }

    return function (gantt) {
      gantt.batchUpdate = createMethod(gantt);
    };

    /***/
  }

  dhtmlx_hooks() {

    if (window.dhtmlx) {

      if (!window.dhtmlx.attaches)
        window.dhtmlx.attaches = {};

      window.dhtmlx.attaches.attachGantt = function (start, end, gantt) {
        var obj: any = document.createElement("DIV");

        gantt = gantt || window.gantt;

        obj.id = "gantt_" + gantt.uid();
        obj.style.width = "100%";
        obj.style.height = "100%";
        obj.cmp = "grid";

        document.body.appendChild(obj);
        this.attachObject(obj.id);
        this.dataType = "gantt";
        this.dataObj = gantt;

        var that = this.vs[this.av];
        that.grid = gantt;

        gantt.init(obj.id, start, end);
        obj.firstChild.style.border = "none";

        that.gridId = obj.id;
        that.gridObj = obj;

        var method_name = "_viewRestore";
        return this.vs[this[method_name]()].grid;
      };

    }
    if (typeof (window.dhtmlXCellObject) != "undefined") {

      window.dhtmlXCellObject.prototype.attachGantt = function (start, end, gantt) {
        gantt = gantt || window.gantt;

        var obj: any = document.createElement("DIV");
        obj.id = "gantt_" + gantt.uid();
        obj.style.width = "100%";
        obj.style.height = "100%";
        obj.cmp = "grid";

        document.body.appendChild(obj);
        this.attachObject(obj.id);

        this.dataType = "gantt";
        this.dataObj = gantt;

        gantt.init(obj.id, start, end);
        obj.firstChild.style.border = "none";

        obj = null;
        this.callEvent("_onContentAttach", []);

        return this.dataObj;
      };
    }

    return null;

    /***/
  }

  // index() {

  index(gantt) {
    if (!gantt.ext) {
      gantt.ext = {};
    }

    var modules = [
      this.autoscroll,
      this.batch_update,
      this.wbs,
      this.jquery_hooks,
      this.dhtmlx_hooks,
      this.resources,
      this.new_task_placeholder,
      this.auto_task_types
    ];

    for (var i = 0; i < modules.length; i++) {
      if (modules[i])
        modules[i](gantt);
    }

    var TimelineZoom = this.timeline_zoom.default;
    gantt.ext.zoom = new TimelineZoom(gantt);
  };

  /***/
  // }

  jqueryHooks() {

    if (window.jQuery) {

      (function ($) {

        var methods = [];
        $.fn.dhx_gantt = function (config) {
          config = config || {};
          if (typeof (config) === 'string') {
            if (methods[config]) {
              return methods[config].apply(this, []);
            } else {
              $.error('Method ' + config + ' does not exist on jQuery.dhx_gantt');
            }
          } else {
            var views = [];
            this.each(function () {
              if (this && this.getAttribute) {
                if (!this.gantt && !(window.gantt.$root == this)) {

                  var newgantt = (window.gantt.$container && window.Gantt) ? window.Gantt.getGanttInstance() : window.gantt;
                  for (var key in config)
                    if (key != "data")
                      newgantt.config[key] = config[key];

                  newgantt.init(this);
                  if (config.data)
                    newgantt.parse(config.data);

                  views.push(newgantt);
                } else
                  views.push(typeof this.gantt == "object" ? this.gantt : window.gantt);
              }
            });


            if (views.length === 1) return views[0];
            return views;
          }
        };

      })(window.jQuery);

    }


    return null;

    /***/
  }

  newTaskPlaceholder() {

    return function addPlaceholder(gantt) {
      function isEnabled() {
        return gantt.config.placeholder_task;
      }

      function callIfEnabled(callback) {
        return function () {
          if (!isEnabled()) {
            return true;
          }
          return callback.apply(this, arguments);
        };
      }

      function silenceDataProcessor(dataProcessor) {
        if (dataProcessor && !dataProcessor._silencedPlaceholder) {
          dataProcessor._silencedPlaceholder = true;
          dataProcessor.attachEvent("onBeforeUpdate", callIfEnabled(function (id, state, data) {
            if (data.type == gantt.config.types.placeholder) {
              dataProcessor.setUpdated(id, false);
              return false;
            }
            return true;
          }));
        }
      }

      function insertPlaceholder() {
        var placeholders = gantt.getTaskBy("type", gantt.config.types.placeholder);
        if (!placeholders.length || !gantt.isTaskExists(placeholders[0].id)) {
          var placeholder = {
            unscheduled: true,
            type: gantt.config.types.placeholder,
            duration: 0,
            text: gantt.locale.labels.new_task
          };
          if (gantt.callEvent("onTaskCreated", [placeholder]) === false) {
            return;
          }

          gantt.addTask(placeholder);

        }
      }

      function afterEdit(id) {
        var item = gantt.getTask(id);
        if (item.type == gantt.config.types.placeholder) {
          if (item.start_date && item.end_date && item.unscheduled) {
            item.unscheduled = false;
          }

          gantt.batchUpdate(function () {
            var newTask = gantt.copy(item);
            gantt.silent(function () {
              gantt.deleteTask(item.id);
            });

            delete newTask["!nativeeditor_status"];
            newTask.type = gantt.config.types.task;
            newTask.id = gantt.uid();
            gantt.addTask(newTask);

            //insertPlaceholder();
          });

        }
      }

      gantt.config.types.placeholder = "placeholder";
      gantt.attachEvent("onDataProcessorReady", callIfEnabled(silenceDataProcessor));

      var ready = false;
      gantt.attachEvent("onGanttReady", function () {
        if (ready) {
          return;
        }
        ready = true;
        gantt.attachEvent("onAfterTaskUpdate", callIfEnabled(afterEdit));
        gantt.attachEvent("onAfterTaskAdd", callIfEnabled(function (id, task) {
          if (task.type != gantt.config.types.placeholder) {
            var placeholders = gantt.getTaskBy("type", gantt.config.types.placeholder);
            placeholders.forEach(function (p) {
              gantt.silent(function () {
                if (gantt.isTaskExists(p.id))
                  gantt.deleteTask(p.id);
              });
            });
            insertPlaceholder();
          }
        }));
        gantt.attachEvent("onParse", callIfEnabled(insertPlaceholder));
      });

      gantt.attachEvent("onBeforeUndoStack", function (action) {
        for (var i = 0; i < action.commands.length; i++) {
          var command = action.commands[i];
          if (command.entity === "task" && command.value.type === gantt.config.types.placeholder) {
            action.commands.splice(i, 1);
            i--;
          }
        }
        return true;
      });

    };

    /***/
  }

  resources() {

    var helpers = this.utilsService.helpers;
    var smartRender = this.renderService.smartRenderWrapper();

    function createResourceMethods(gantt) {

      var resourceTaskCache = {};

      gantt.$data.tasksStore.attachEvent("onStoreUpdated", function () {
        resourceTaskCache = {};
      });

      function getTaskBy(propertyName, propertyValue) {
        if (typeof propertyName == "function") {
          return filterResourceTasks(propertyName);
        } else {
          if (helpers.isArray(propertyValue)) {
            return getResourceTasks(propertyName, propertyValue);
          } else {
            return getResourceTasks(propertyName, [propertyValue]);
          }
        }
      }

      function filterResourceTasks(filter) {
        var res = [];
        gantt.eachTask(function (task) {
          if (filter(task)) {
            res.push(task);
          }
        });
        return res;
      }

      var falsyValuePreffix = String(Math.random());
      function resourceHashFunction(value) {
        if (value === null) {
          return falsyValuePreffix + String(value);
        }
        return String(value);
      }

      function getResourceTasks(property, resourceIds) {
        var res;
        var cacheKey = resourceIds.join("_") + "_" + property;
        var resourceHash = {};
        helpers.forEach(resourceIds, function (resourceId) {
          resourceHash[resourceHashFunction(resourceId)] = true;
        });

        if (!resourceTaskCache[cacheKey]) {
          res = resourceTaskCache[cacheKey] = [];
          gantt.eachTask(function (task) {
            if (task.type == gantt.config.types.project) return;
            if (property in task) {
              var resourceValue;
              if (!helpers.isArray(task[property])) {
                resourceValue = [task[property]];
              } else {
                resourceValue = task[property];
              }
              helpers.forEach(resourceValue, function (value) {
                if (resourceHash[resourceHashFunction(value)] || (value && resourceHash[resourceHashFunction(value.resource_id)])) {
                  res.push(task);
                }
              });

            }
          });
        } else {
          res = resourceTaskCache[cacheKey];
        }

        return res;
      }

      function getResourceLoad(resource, resourceProperty, scale, timeline) {
        var cacheKey = resource.id + "_" + resourceProperty + "_" + scale.unit + "_" + scale.step;
        var res;
        if (!resourceTaskCache[cacheKey]) {
          res = resourceTaskCache[cacheKey] = calculateResourceLoad(resource, resourceProperty, scale, timeline);

        } else {
          res = resourceTaskCache[cacheKey];
        }
        return res;
      }

      function calculateResourceLoad(resource, resourceProperty, scale, timeline) {

        var tasks;
        if (resource.$role == "task") {
          tasks = [];
        } else {
          tasks = getTaskBy(resourceProperty, resource.id);
        }
        var step = scale.unit;
        var timegrid = {};

        for (var i = 0; i < tasks.length; i++) {
          var task = tasks[i];

          var currDate = gantt.date[step + "_start"](new Date(task.start_date));

          while (currDate < task.end_date) {

            var date = currDate;
            currDate = gantt.date.add(currDate, 1, step);

            if (!gantt.isWorkTime({ date: date, task: task, unit: step })) {
              continue;
            }

            var timestamp = date.valueOf();
            if (!timegrid[timestamp]) {
              timegrid[timestamp] = [];
            }

            timegrid[timestamp].push(task);
          }
        }

        var timetable = [];
        var start, end, tasks;
        var config = timeline.$getConfig();

        for (var i = 0; i < scale.trace_x.length; i++) {
          start = new Date(scale.trace_x[i]);
          end = gantt.date.add(start, 1, step);
          tasks = timegrid[start.valueOf()] || [];
          if (tasks.length || config.resource_render_empty_cells) {
            timetable.push({
              start_date: start,
              end_date: end,
              tasks: tasks
            });
          }

        }

        return timetable;
      }

      function isInViewPort(item, view, viewport) {
        var position = view.getItemTop(item.id);
        var height = view.getItemHeight(item);
        if (viewport.y > position + height || viewport.y_end < position) {
          return false;
        } else {
          return true;
        }
      }

      function generateRenderResourceLine() {

        var renderedResourceLines = {};

        function renderResourceLineCell(resource, day, templates, config, timeline) {
          var css = templates.resource_cell_class(day.start_date, day.end_date, resource, day.tasks);
          var content = templates.resource_cell_value(day.start_date, day.end_date, resource, day.tasks);

          if (css || content) {
            var sizes = timeline.getItemPosition(resource, day.start_date, day.end_date);
            var el = document.createElement('div');
            el.className = ["gantt_resource_marker", css].join(" ");

            el.style.cssText = [
              'left:' + sizes.left + 'px',
              'width:' + sizes.width + 'px',
              'height:' + (config.row_height - 1) + 'px',
              'line-height:' + (config.row_height - 1) + 'px',
              'top:' + sizes.top + 'px'
            ].join(";");

            if (content)
              el.innerHTML = content;

            return el;
          }
          return null;
        }

        function detachRenderedResourceLine(id, index) {
          if (renderedResourceLines[id] && renderedResourceLines[id][index] &&
            renderedResourceLines[id][index].parentNode
          ) {
            renderedResourceLines[id][index].parentNode.removeChild(renderedResourceLines[id][index]);
          }
        }

        function renderResourceLine(resource, timeline, viewport) {
          if (!isInViewPort(resource, timeline, viewport)) {
            return null;
          }
          var config = timeline.$getConfig(),
            templates = timeline.$getTemplates();
          var scale = timeline.getScale();
          var timetable = getResourceLoad(resource, config.resource_property, timeline.getScale(), timeline);

          var cells = [];
          renderedResourceLines[resource.id] = {};
          for (var i = 0; i < timetable.length; i++) {

            var day = timetable[i];
            var columnIndex = scale.trace_indexes[day.start_date.valueOf()];
            if (!isColumnVisible(columnIndex, scale, viewport)) {
              continue;
            }

            var cell = renderResourceLineCell(resource, day, templates, config, timeline);
            if (cell) {
              cells.push(cell);
              renderedResourceLines[resource.id][columnIndex] = cell;
            }
          }

          var row = null;
          if (cells.length) {
            row = document.createElement("div");
            for (var i = 0; i < cells.length; i++) {
              row.appendChild(cells[i]);
            }
          }
          return row;
        }

        function updateResourceLine(resource, timeline, engine, viewport) {
          if (!isInViewPort(resource, timeline, viewport)) {
            return null;
          }
          var row = engine.rendered[resource.id];
          var config = timeline.$getConfig(),
            templates = timeline.$getTemplates();
          var scale = timeline.getScale();
          var timetable = getResourceLoad(resource, config.resource_property, timeline.getScale(), timeline);

          for (var i = 0; i < timetable.length; i++) {

            var day = timetable[i];
            var columnIndex = scale.trace_indexes[day.start_date.valueOf()];
            if (!isColumnVisible(columnIndex, scale, viewport)) {
              detachRenderedResourceLine(resource.id, columnIndex);
              continue;
            }

            if (!renderedResourceLines[resource.id] || !renderedResourceLines[resource.id][columnIndex]) {
              var cell = renderResourceLineCell(resource, day, templates, config, timeline);
              if (cell) {
                row.appendChild(cell);
                renderedResourceLines[resource.id][columnIndex] = cell;
              }
            }
            else if (renderedResourceLines[resource.id] && renderedResourceLines[resource.id][columnIndex] && !renderedResourceLines[resource.id][columnIndex].parentNode) {
              row.appendChild(renderedResourceLines[resource.id][columnIndex]);
            }
          }
        }

        return smartRender(renderResourceLine, updateResourceLine, isInViewPort, true);
      }

      function renderBar(level, start, end, timeline) {
        var top = (1 - (level * 1 || 0)) * 100;
        var left = timeline.posFromDate(start);
        var right = timeline.posFromDate(end);
        var element = document.createElement("div");
        element.className = "gantt_histogram_hor_bar";
        element.style.top = top + '%';
        element.style.left = left + "px";
        element.style.width = (right - left + 1) + "px";
        return element;
      }
      function renderConnection(prevLevel, nextLevel, left) {
        if (prevLevel === nextLevel) {
          return null;
        }

        var top = 1 - Math.max(prevLevel, nextLevel);
        var height = Math.abs(prevLevel - nextLevel);
        var element = document.createElement("div");
        element.className = "gantt_histogram_vert_bar";
        element.style.top = top * 100 + "%";
        element.style.height = height * 100 + "%";
        element.style.left = left + "px";

        return element;
      }

      function isColumnVisible(columnIndex, scale, viewPort) {
        var width = scale.width[columnIndex];
        var cellLeftCoord = scale.left[columnIndex] - width;
        var cellRightCoord = scale.left[columnIndex] + width;
        return (width > 0 && cellLeftCoord <= viewPort.x_end && cellRightCoord >= viewPort.x);//do not render skipped columns
      }



      function generateRenderResourceHistogram() {

        var renderedHistogramCells = {};
        var renderedHistogramRows = {};
        var renderedHistogramCapacity = {};

        function detachRenderedHistogramCell(id, index) {

          var renderedRow = renderedHistogramCells[id];
          if (renderedRow && renderedRow[index] &&
            renderedRow[index].parentNode
          ) {
            renderedRow[index].parentNode.removeChild(renderedRow[index]);
          }
        }

        function renderHistogramLine(capacity, timeline, maxCapacity, viewPort) {
          var scale = timeline.getScale();

          var el = document.createElement("div");

          for (var i = 0; i < scale.trace_x.length; i++) {
            if (!isColumnVisible(i, scale, viewPort)) {
              continue;
            }

            var colStart = scale.trace_x[i];
            var colEnd = scale.trace_x[i + 1] || gantt.date.add(colStart, scale.step, scale.unit);
            var col = scale.trace_x[i].valueOf();
            var level = Math.min(capacity[col] / maxCapacity, 1) || 0;
            // do not render histogram for lines with below zero capacity, as it's reserved for folders
            if (level < 0) {
              return null;
            }

            var nextLevel = Math.min(capacity[colEnd.valueOf()] / maxCapacity, 1) || 0;
            var bar = renderBar(level, colStart, colEnd, timeline);
            if (bar) {
              el.appendChild(bar);
            }
            var connection = renderConnection(level, nextLevel, timeline.posFromDate(colEnd));
            if (connection) {
              el.appendChild(connection);
            }

          }
          return el;
        }

        function renderCapacityElement(resource, sizes, capacityMatrix, config, timeline, maxCapacity, viewport) {

          var renderedElement = renderedHistogramCapacity[resource.id];
          if (renderedElement && renderedElement.parentNode) {
            renderedElement.parentNode.removeChild(renderedElement);
          }

          var capacityElement: any = renderHistogramLine(capacityMatrix, timeline, maxCapacity, viewport);
          if (capacityElement) {
            capacityElement.setAttribute("data-resource-id", resource.id);
            capacityElement.style.position = "absolute";
            capacityElement.style.top = (sizes.top + 1) + "px";
            capacityElement.style.height = (config.row_height - 1) + "px";
            capacityElement.style.left = 0;
          }
          return capacityElement;
        }

        function renderHistogramCell(resource, sizes, maxCapacity, config, templates, day) {
          var css = templates.histogram_cell_class(day.start_date, day.end_date, resource, day.tasks);
          var content = templates.histogram_cell_label(day.start_date, day.end_date, resource, day.tasks);
          var fill = templates.histogram_cell_allocated(day.start_date, day.end_date, resource, day.tasks);
          if (css || content) {
            var el = document.createElement('div');
            el.className = ["gantt_histogram_cell", css].join(" ");

            el.style.cssText = [
              'left:' + sizes.left + 'px',
              'width:' + sizes.width + 'px',
              'height:' + (config.row_height - 1) + 'px',
              'line-height:' + (config.row_height - 1) + 'px',
              'top:' + (sizes.top + 1) + 'px'
            ].join(";");


            if (content) {
              content = "<div class='gantt_histogram_label'>" + content + "</div>";
            }

            if (fill) {
              content = "<div class='gantt_histogram_fill' style='height:" + (Math.min(fill / maxCapacity || 0, 1) * 100) + "%;'></div>" + content;
            }

            if (content) {
              el.innerHTML = content;
            }

            return el;
          }
          return null;
        }

        function renderResourceHistogram(resource, timeline, viewport) {
          if (!isInViewPort(resource, timeline, viewport)) {
            return null;
          }
          var config = timeline.$getConfig(),
            templates = timeline.$getTemplates();
          var scale = timeline.getScale();
          var timetable = getResourceLoad(resource, config.resource_property, scale, timeline);

          var cells = [];
          var capacityMatrix = {};
          var maxCapacity = resource.capacity || timeline.$config.capacity || 24;
          renderedHistogramCells[resource.id] = {};
          renderedHistogramRows[resource.id] = null;
          renderedHistogramCapacity[resource.id] = null;
          for (var i = 0; i < timetable.length; i++) {
            var day = timetable[i];
            var columnIndex = scale.trace_indexes[day.start_date.valueOf()];
            if (!isColumnVisible(columnIndex, scale, viewport)) {
              continue;
            }

            var capacity = templates.histogram_cell_capacity(day.start_date, day.end_date, resource, day.tasks);
            capacityMatrix[day.start_date.valueOf()] = capacity || 0;
            var sizes = timeline.getItemPosition(resource, day.start_date, day.end_date);

            var el = renderHistogramCell(resource, sizes, maxCapacity, config, templates, day);
            if (el) {
              cells.push(el);
              renderedHistogramCells[resource.id][columnIndex] = el;
            }
          }

          var row = null;
          if (cells.length) {
            row = document.createElement("div");
            for (var i = 0; i < cells.length; i++) {
              row.appendChild(cells[i]);
            }

            var capacityElement = renderCapacityElement(resource, sizes, capacityMatrix, config, timeline, maxCapacity, viewport);
            if (capacityElement) {
              row.appendChild(capacityElement);
              renderedHistogramCapacity[resource.id] = capacityElement;
            }
            renderedHistogramRows[resource.id] = row;
          }

          return row;
        }

        function updateResourceHistogram(resource, timeline, engine, viewport) {
          if (!isInViewPort(resource, timeline, viewport)) {
            return null;
          }
          var row = engine.rendered[resource.id];

          var config = timeline.$getConfig(),
            templates = timeline.$getTemplates();
          var scale = timeline.getScale();
          var timetable = getResourceLoad(resource, config.resource_property, scale, timeline);
          var maxCapacity = resource.capacity || timeline.$config.capacity || 24;
          var capacityMatrix = {};

          for (var i = 0; i < timetable.length; i++) {
            var day = timetable[i];
            var columnIndex = scale.trace_indexes[day.start_date.valueOf()];
            var capacity = templates.histogram_cell_capacity(day.start_date, day.end_date, resource, day.tasks);
            capacityMatrix[day.start_date.valueOf()] = capacity || 0;
            var sizes = timeline.getItemPosition(resource, day.start_date, day.end_date);

            if (!isColumnVisible(columnIndex, scale, viewport)) {
              detachRenderedHistogramCell(resource.id, columnIndex);
              continue;
            }

            var renderedCell = renderedHistogramCells[resource.id];
            if (!renderedCell || !renderedCell[columnIndex]) {
              var el = renderHistogramCell(resource, sizes, maxCapacity, config, templates, day);
              if (el) {
                row.appendChild(el);
                renderedHistogramCells[resource.id][columnIndex] = el;
              }
            }
            else if (renderedCell && renderedCell[columnIndex] && !renderedCell[columnIndex].parentNode) {
              row.appendChild(renderedCell[columnIndex]);
            }
          }

          var capacityElement = renderCapacityElement(resource, sizes, capacityMatrix, config, timeline, maxCapacity, viewport);
          if (capacityElement) {
            row.appendChild(capacityElement);
            renderedHistogramCapacity[resource.id] = capacityElement;
          }
        }

        return smartRender(renderResourceHistogram, updateResourceHistogram, isInViewPort, true);
      }


      function selectAssignments(resourceId, taskId, result) {
        var property = gantt.config.resource_property;
        var owners = [];
        if (gantt.getDatastore("task").exists(taskId)) {
          var task = gantt.getTask(taskId);
          owners = task[property] || [];
        }

        if (!Array.isArray(owners)) {
          owners = [owners];
        }
        for (var i = 0; i < owners.length; i++) {
          if (owners[i].resource_id == resourceId) {
            result.push({ task_id: task.id, resource_id: owners[i].resource_id, value: owners[i].value });
          }
        }
      }

      function getResourceAssignments(resourceId, taskId) {
        // resource assignment as an independent module:
        // {taskId:, resourceId, value}
        // TODO: probably should add a separate datastore for these
        var assignments = [];
        var property = gantt.config.resource_property;
        if (taskId !== undefined) {
          selectAssignments(resourceId, taskId, assignments);
        } else {
          var tasks = gantt.getTaskBy(property, resourceId);
          tasks.forEach(function (task) {
            selectAssignments(resourceId, task.id, assignments);
          });
        }
        return assignments;
      }

      return {
        renderLine: generateRenderResourceLine,
        renderHistogram: generateRenderResourceHistogram,
        filterTasks: getTaskBy,
        getResourceAssignments: getResourceAssignments
      };
    }

    return function (gantt) {
      var methods = createResourceMethods(gantt);

      gantt.getTaskBy = methods.filterTasks;
      gantt.getResourceAssignments = methods.getResourceAssignments;
      gantt.$ui.layers.resourceRow = methods.renderLine;
      gantt.$ui.layers.resourceHistogram = methods.renderHistogram;
      gantt.config.resource_property = "owner_id";
      gantt.config.resource_store = "resource";
      gantt.config.resource_render_empty_cells = false;

      /**
       * these are placeholder functions that should be redefined by the user
      */
      gantt.templates.histogram_cell_class = function (start_date, end_date, resource, tasks) { };
      gantt.templates.histogram_cell_label = function (start_date, end_date, resource, tasks) {
        return tasks.length + "/3";
      };
      gantt.templates.histogram_cell_allocated = function (start_date, end_date, resource, tasks) {
        return tasks.length / 3;
      };
      gantt.templates.histogram_cell_capacity = function (start_date, end_date, resource, tasks) {
        return 0;
      };



      gantt.templates.resource_cell_class = function (start, end, resource, tasks) {
        var css = "";
        if (tasks.length <= 1) {
          css = "gantt_resource_marker_ok";
        } else {
          css = "gantt_resource_marker_overtime";
        }
        return css;
      };

      gantt.templates.resource_cell_value = function (start, end, resource, tasks) {
        return tasks.length * 8;
      };
    };




    /***/
  }

  timelineZoom() {

    // "use strict";

    // Object.defineProperty(exports, "__esModule", { value: true });
    var env = this.utilsService.env();
    var eventable = this.utilsService.eventable();
    var USE_KEY = ["ctrlKey", "altKey", "shiftKey", "metaKey"];
    var _defaultScales = [
      [
        {
          unit: "month",
          date: "%M",
          step: 1
        },
        {
          unit: "day",
          date: "%d",
          step: 1
        }
      ],
      [
        {
          unit: "day",
          date: "%d %M",
          step: 1
        }
      ],
      [
        {
          unit: "day",
          date: "%d %M",
          step: 1
        },
        {
          unit: "hour",
          date: "%H:00",
          step: 8
        },
      ],
      [
        {
          unit: "day",
          date: "%d %M",
          step: 1
        },
        {
          unit: "hour",
          date: "%H:00",
          step: 1
        },
      ],
    ];
    var TimelineZoom = /** @class */ (function () {
      function TimelineZoom(gantt) {
        var _this = this;
        this.zoomIn = function () {
          var index = _this.getCurrentLevel() - 1;
          if (index < 0) {
            return;
          }
          _this.setLevel(index);
        };
        this.zoomOut = function () {
          var index = _this.getCurrentLevel() + 1;
          if (index > _this._levels.length - 1) {
            return;
          }
          _this.setLevel(index);
        };
        this.getCurrentLevel = function () {
          return _this._activeLevelIndex;
        };
        this.getLevels = function () {
          return _this._levels;
        };
        this.setLevel = function (level) {
          var zoomLevel = _this._getZoomIndexByName(level);
          if (zoomLevel === -1) {
            _this.$gantt.assert(zoomLevel !== -1, "Invalid zoom level for gantt.ext.zoom.setLevel. " + level + " is not an expected value.");
          }
          _this._setLevel(zoomLevel, 0);
        };
        this._getZoomIndexByName = function (levelName) {
          var zoomLevel = -1;
          if (typeof levelName === "string") {
            if (!isNaN(Number(levelName)) && _this._levels[Number(levelName)]) {
              zoomLevel = Number(levelName);
            }
            else {
              for (var i = 0; i < _this._levels.length; i++) {
                if (_this._levels[i].name === levelName) {
                  zoomLevel = i;
                  break;
                }
              }
            }
          }
          else {
            zoomLevel = levelName;
          }
          return zoomLevel;
        };
        this._getVisibleDate = function () {
          var scrollPos = _this.$gantt.getScrollState().x;
          var viewPort = _this.$gantt.$task.offsetWidth;
          _this._visibleDate = _this.$gantt.dateFromPos(scrollPos + viewPort / 2);
        };
        this._setLevel = function (level, cursorOffset) {
          _this._activeLevelIndex = level;
          var gantt = _this.$gantt;
          var nextConfig = gantt.copy(_this._levels[_this._activeLevelIndex]);
          var chartConfig = gantt.copy(nextConfig);
          delete chartConfig.name;
          gantt.mixin(gantt.config, chartConfig, true);
          var isRendered = !!gantt.$root;
          if (isRendered) {
            if (cursorOffset) {
              var cursorDate = _this.$gantt.dateFromPos(cursorOffset + _this.$gantt.getScrollState().x);
              _this.$gantt.render();
              var newPosition = _this.$gantt.posFromDate(cursorDate);
              _this.$gantt.scrollTo(newPosition - cursorOffset);
            }
            else {
              var viewPort = _this.$gantt.$task.offsetWidth;
              if (!_this._visibleDate) {
                _this._getVisibleDate();
              }
              var middleDate = _this._visibleDate;
              _this.$gantt.render();
              var newPosition = _this.$gantt.posFromDate(middleDate);
              _this.$gantt.scrollTo(newPosition - viewPort / 2);
            }
            _this.callEvent("onAfterZoom", [_this._activeLevelIndex, nextConfig]);
          }
        };
        this._attachWheelEvent = function (config) {
          var event = env.isFF ? "wheel" : "mousewheel";
          var el;
          if (typeof config.element === "function") {
            el = config.element();
          }
          else {
            el = config.element;
          }
          if (!el) {
            return;
          }
          _this._domEvents.attach(el, event, _this.$gantt.bind(function (e) {
            if (this._useKey) {
              if (USE_KEY.indexOf(this._useKey) < 0) {
                return false;
              }
              if (!e[this._useKey]) {
                return false;
              }
            }
            if (typeof this._handler === "function") {
              this._handler.apply(this, [e]);
              return true;
            }
          }, _this));
        };
        this._defaultHandler = function (e) {
          var timelineOffset = _this.$gantt.$task.getBoundingClientRect().x;
          var cursorOffset = e.clientX - timelineOffset;
          var wheelY = _this.$gantt.env.isFF ? (e.deltaY * -40) : e.wheelDelta;
          var wheelUp = false;
          if (wheelY > 0) {
            wheelUp = true;
          }
          e.preventDefault();
          e.stopPropagation();
          _this._setScaleSettings(wheelUp, cursorOffset);
        };
        this._setScaleDates = function () {
          if (_this._initialStartDate && _this._initialEndDate) {
            _this.$gantt.config.start_date = _this._initialStartDate;
            _this.$gantt.config.end_date = _this._initialEndDate;
          }
        };
        this.$gantt = gantt;
        this._domEvents = this.$gantt._createDomEventScope();
      }
      TimelineZoom.prototype.init = function (config) {
        var _this = this;
        this._initialStartDate = config.startDate;
        this._initialEndDate = config.endDate;
        this._activeLevelIndex = config.activeLevelIndex ? config.activeLevelIndex : 0;
        this._levels = this._mapScales(config.levels || _defaultScales);
        this._handler = config.handler || this._defaultHandler;
        this._minColumnWidth = config.minColumnWidth || 60;
        this._maxColumnWidth = config.maxColumnWidth || 240;
        this._widthStep = config.widthStep || 3 / 8 * config.minColumnWidth;
        this._useKey = config.useKey;
        if (!this._initialized) {
          eventable(this);
          this.$gantt.attachEvent("onGanttScroll", function () {
            _this._getVisibleDate();
          });
        }
        this._domEvents.detachAll();
        if (config.trigger === "wheel") {
          if (this.$gantt.$root) {
            this._attachWheelEvent(config);
          }
          else {
            this.$gantt.attachEvent("onGanttReady", function () {
              _this._attachWheelEvent(config);
            });
          }
        }
        this._initialized = true;
        this.setLevel(this._activeLevelIndex);
      };
      TimelineZoom.prototype._mapScales = function (levels) {
        return levels.map(function (l) {
          if (Array.isArray(l)) {
            return {
              scales: l
            };
          }
          else {
            return l;
          }
        });
      };
      TimelineZoom.prototype._setScaleSettings = function (wheelUp, cursorOffset) {
        if (wheelUp) {
          this._stepUp(cursorOffset);
        }
        else {
          this._stepDown(cursorOffset);
        }
      };
      TimelineZoom.prototype._stepUp = function (cursorOffset) {
        if (this._activeLevelIndex >= this._levels.length - 1) {
          return;
        }
        var nextLevel = this._activeLevelIndex;
        this._setScaleDates();
        if (this._widthStep) {
          var newColumnWidth = this.$gantt.config.min_column_width + this._widthStep;
          if (newColumnWidth > this._maxColumnWidth) {
            newColumnWidth = this._minColumnWidth;
            nextLevel++;
          }
          this.$gantt.config.min_column_width = newColumnWidth;
        }
        else {
          nextLevel++;
        }
        this._setLevel(nextLevel, cursorOffset);
      };
      TimelineZoom.prototype._stepDown = function (cursorOffset) {
        if (this._activeLevelIndex < 1) {
          return;
        }
        var nextLevel = this._activeLevelIndex;
        this._setScaleDates();
        if (this._widthStep) {
          var newColumnWidth = this.$gantt.config.min_column_width - this._widthStep;
          if (newColumnWidth < this._minColumnWidth) {
            newColumnWidth = this._maxColumnWidth;
            nextLevel--;
          }
          this.$gantt.config.min_column_width = newColumnWidth;
        }
        else {
          nextLevel--;
        }
        this._setLevel(nextLevel, cursorOffset);
      };
      return TimelineZoom;
    }());
    exports.default = TimelineZoom;


    /***/
  }

  wbs() {

    var createWbs = (function (gantt) {
      return {
        _needRecalc: true,
        reset: function () {
          this._needRecalc = true;
        },
        _isRecalcNeeded: function () {
          return (!this._isGroupSort() && this._needRecalc);
        },
        _isGroupSort: function () {
          return !!(gantt.getState().group_mode);
        },
        _getWBSCode: function (task) {
          if (!task) return "";

          if (this._isRecalcNeeded()) {
            this._calcWBS();
          }

          if (task.$virtual) return "";
          if (this._isGroupSort()) return task.$wbs || "";

          if (!task.$wbs) {
            this.reset();
            this._calcWBS();
          }
          return task.$wbs;
        },
        _setWBSCode: function (task, value) {
          task.$wbs = value;
        },
        getWBSCode: function (task) {
          return this._getWBSCode(task);
        },
        getByWBSCode: function (code) {
          var parts = code.split(".");
          var currentNode = gantt.config.root_id;
          for (var i = 0; i < parts.length; i++) {
            var children = gantt.getChildren(currentNode);
            var index = parts[i] * 1 - 1;
            if (gantt.isTaskExists(children[index])) {
              currentNode = children[index];
            } else {
              return null;
            }
          }
          if (gantt.isTaskExists(currentNode)) {
            return gantt.getTask(currentNode);
          } else {
            return null;
          }
        },
        _calcWBS: function () {
          if (!this._isRecalcNeeded()) return;

          var _isFirst = true;
          gantt.eachTask(function (ch) {
            if (_isFirst) {
              _isFirst = false;
              this._setWBSCode(ch, "1");
              return;
            }
            var _prevSibling = gantt.getPrevSibling(ch.id);
            if (_prevSibling !== null) {
              var _wbs = gantt.getTask(_prevSibling).$wbs;
              if (_wbs) {
                _wbs = _wbs.split(".");
                _wbs[_wbs.length - 1]++;
                this._setWBSCode(ch, _wbs.join("."));
              }
            } else {
              var _parent = gantt.getParent(ch.id);
              this._setWBSCode(ch, gantt.getTask(_parent).$wbs + ".1");
            }
          }, gantt.config.root_id, this);

          this._needRecalc = false;
        }
      };
    });

    return function (gantt) {
      var wbs = createWbs(gantt);
      gantt.getWBSCode = function getWBSCode(task) {
        return wbs.getWBSCode(task);
      };

      gantt.getTaskByWBSCode = function (code) {
        return wbs.getByWBSCode(code);
      };

      function resetCache() {
        wbs.reset();
        return true;
      }

      gantt.attachEvent("onAfterTaskMove", resetCache);
      gantt.attachEvent("onBeforeParse", resetCache);
      gantt.attachEvent("onAfterTaskDelete", resetCache);
      gantt.attachEvent("onAfterTaskAdd", resetCache);
      gantt.attachEvent("onAfterSort", resetCache);

    };


    /***/
  }
}
