import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WorkUnitCacheService {

  constructor() { }

  index() {

    // "use strict";

    // Object.defineProperty(exports, "__esModule", { value: true });
    var workunit_map_cache_1 = this.workunitMapCache();
    var workunit_object_cache_1 = this.workunitObjectCache();
    function createCacheObject() {
      // worktime hash is on the hot path,
      // Map seems to work faster than plain array, use it whenever possible
      if (typeof Map !== "undefined") {
        return new workunit_map_cache_1.WorkUnitsMapCache();
      }
      else {
        return new workunit_object_cache_1.WorkUnitsObjectCache();
      }
    }
    return {createCacheObject : createCacheObject };


    /***/
  }

  workunitMapCache() {

    // "use strict";

    // Object.defineProperty(exports, "__esModule", { value: true });
    var WorkUnitsMapCache = /** @class */ (function () {
      function WorkUnitsMapCache() {
        this.clear();
      }
      WorkUnitsMapCache.prototype.getItem = function (unit, timestamp) {
        if (this._cache.has(unit)) {
          var unitCache = this._cache.get(unit);
          if (unitCache.has(timestamp)) {
            return unitCache.get(timestamp);
          }
        }
        return -1;
      };
      WorkUnitsMapCache.prototype.setItem = function (unit, timestamp, value) {
        if (!unit || !timestamp) {
          return;
        }
        var cache = this._cache;
        var unitCache;
        if (!cache.has(unit)) {
          unitCache = new Map();
          cache.set(unit, unitCache);
        }
        else {
          unitCache = cache.get(unit);
        }
        unitCache.set(timestamp, value);
      };
      WorkUnitsMapCache.prototype.clear = function () {
        this._cache = new Map();
      };
      return WorkUnitsMapCache;
    }());
    return {WorkUnitsMapCache : WorkUnitsMapCache };


    /***/
  }

  workunitObjectCache() {

    // "use strict";

    // Object.defineProperty(exports, "__esModule", { value: true });
    var WorkUnitsObjectCache = /** @class */ (function () {
      function WorkUnitsObjectCache() {
        this.clear();
      }
      WorkUnitsObjectCache.prototype.getItem = function (unit, timestamp) {
        var cache = this._cache;
        if (cache && cache[unit]) {
          var units = cache[unit];
          if (units[timestamp] !== undefined) {
            return units[timestamp];
          }
        }
        return -1;
      };
      WorkUnitsObjectCache.prototype.setItem = function (unit, timestamp, value) {
        if (!unit || !timestamp) {
          return;
        }
        var cache = this._cache;
        if (!cache) {
          return;
        }
        if (!cache[unit]) {
          cache[unit] = {};
        }
        cache[unit][timestamp] = value;
      };
      WorkUnitsObjectCache.prototype.clear = function () {
        this._cache = {};
      };
      return WorkUnitsObjectCache;
    }());
    return { WorkUnitsObjectCache : WorkUnitsObjectCache};


    /***/
  }
}
