import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { DatePipe } from '@angular/common';
// import 'dhtmlx-gantt';
import { CoreService } from '../services/core/core.service';

@Component({
  encapsulation: ViewEncapsulation.None,
  selector: 'app-gantt',
  templateUrl: './gantt.component.html',
  styleUrls: ['./gantt.component.css'],
  // providers: [GanttService],
})
export class GanttComponent implements OnInit {
  ext: {};
  keys: { edit_save: any; edit_cancel: any; };
  constructor(private datepipe: DatePipe, private coreService: CoreService) { }
  @ViewChild('gantt_here') ganttContainer: ElementRef;

  constants;
  templates;

  ngOnInit() {

    // gantt.init(this.ganttContainer.nativeElement);
    // this.ganttService.gantt(this.ganttContainer.nativeElement);
      this.coreService.gantt(this.ganttContainer.nativeElement);
  }
}

//   /***/ "./sources/dhtmlxgantt.gpl.ts":
// /*!************************************!*\
//   !*** ./sources/dhtmlxgantt.gpl.ts ***!
//   \************************************/
// /*! no static exports found */
// /***/ (function(module, exports, __webpack_require__) {

// "use strict";

// Object.defineProperty(exports, "__esModule", { value: true });
// var warnings = __webpack_require__(/*! ./core/deprecated_warnings */ "./sources/core/deprecated_warnings.js");
// var base = __webpack_require__(/*! ./core/gantt */ "./sources/core/gantt.js");
// var gantt = window.gantt = base();
// exports.gantt = gantt;
// warnings(gantt);
// exports.default = gantt;


// /***/ }),
